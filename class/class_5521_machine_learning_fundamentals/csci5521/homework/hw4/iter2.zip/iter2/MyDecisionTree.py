"""
In this programming assignment, we are going to implement the decision tree with recursion. The recommended implementation order of the functions are:
1. compute_node_entropy: compute node entropy based with the given labels (sum -p*log2(p+1e-15), where p is the probability of each label)
2. compute_split_entropy: given the left and right labels of the split, first compute the entropy of left and right labels with (1), and then weighted combine them to get the split entropy
3. select_features: given the data and label, iterate through all possible features for split, and use (2) to compute the entropy. Select the feature index with best(lowest) entropy
4. generate_tree: given all the data/label and min_entropy, generate the tree with recursion: the structure could be like follow: (Stop Criteria; Find the feature of current split (3); recursively             call itself again with left/right data/labels). With this structure, the function will recursively find the feature and also the feature for their left/right children, until the stop criteria is reached
5. Decision_tree.predict: given each test data, you can traverse the tree to find its corresponding labels and return the labels
--------------------
Here are some clarifications:
For all test, we only test the functionality of each function, please report your answers in the pdf files.
To ensure a deterministic result, don't shuffle data.
"""

import numpy as np

class Tree_node:
    """
    Data structure for nodes in the decision-tree
    """
    def __init__(self,):
        self.feature = None # index of the selected feature (for non-leaf node)
        self.label = -1 # class label (for leaf node), -1 means the node is not a leaf node
        self.left_child = None # left child node
        self.right_child = None # right child node

class Decision_tree:
    """
    Decision tree with binary features
    """
    def __init__(self,min_entropy):
        self.min_entropy = min_entropy
        self.root = None

    def fit(self,train_x,train_y):
        # construct the decision-tree with recursion
        self.root = self.generate_tree(train_x,train_y)

    def predict(self,test_x):
        # iterate through all samples
        prediction = np.zeros([len(test_x),]).astype('int') # placeholder
        for i in range(len(test_x)):
            # traverse the decision-tree based on the features of the current sample till reaching a leaf node
            pass # placeholder

        return prediction

    def generate_tree(self,data,label):
        # initialize the current tree node
        cur_node = Tree_node()

        # compute the node entropy
        node_entropy = self.compute_node_entropy(label)

        # determine if the current node is a leaf node based on minimum node entropy (if yes, find the corresponding class label with majority voting and exit the current recursion)


        # select the feature that will best split the current non-leaf node
        selected_feature = self.select_feature(data,label)
        cur_node.feature = selected_feature

        # split the data based on the selected feature and start the next level of recursion


        return cur_node

    def select_feature(self,data,label):
        # iterate through all features and compute their corresponding entropy
        best_feat = 0

        for i in range(len(data[0])):

            # compute the entropy of splitting based on the selected features
            pass

            # select the feature with minimum entropy

        return best_feat

    def compute_split_entropy(self,left_y,right_y):
        # compute the entropy of a potential split (with compute_node_entropy function), left_y and right_y are labels for the two branches
        split_entropy = -1 # placeholder

        return split_entropy

    def compute_node_entropy(self,label):
        # compute the entropy of a tree node (add 1e-15 inside the log2 when computing the entropy to prevent numerical issue)
        # sum -p*log2(p+1e-15)
        node_entropy = np.sum(-label * np.log2(label+1e-15))

        return node_entropy
