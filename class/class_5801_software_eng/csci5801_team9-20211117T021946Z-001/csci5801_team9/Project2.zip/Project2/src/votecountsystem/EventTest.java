package votecountsystem;

import static org.junit.Assert.*;
import org.junit.*;


/**
 * Class name: EventTest
 * Author: Isaac Xiong, Luke Chen
 * Description: This class will test the Event class and it's functionality.
 *
 */
public class EventTest {
  
	Event event1, event2, event3;
	
	/**
	 * Setups the event objects
	 */
	@Before
	public void setup() {
		event1 = new Event("John", 1, "added");
		event2 = new Event("John", -1, "win");
		event3 = new Event("N/A", 1, "discarded");
	}
	
	/**
	 * Add string to an event
	 */
	@Test
	public void testAdded() {
        assertEquals("John,1,added", event1.toString());
	}
	
	/**
	 * Event where winner shown
	 */
	@Test
	public void testWin() {
		assertEquals("John,no ballot involved,win", event2.toString());
	}
	
	/**
	 * Event where candidate discarded
	 */
	@Test
	public void testDiscard() {
		assertEquals("no candidate involved,1,discarded", event3.toString());
	}
}

