package votecountsystem;

import static org.junit.Assert.*;

import org.junit.Test;
import java.util.*;

import static org.hamcrest.CoreMatchers.*;



/**
 * @author Isaac Xiong
 */

/**
 * Description: This class will test the Candidate class and it's functionality.
 *
 */
public class CandidateTest {
	/**
	 * 	Initialize a candidate for testing
	 * 
	 */
	Candidate cand1 = new Candidate("Terry", 'R');
	int[] choices1 = new int[] {1,0,0};
	int[] choices2 = new int[] {1,2,3};
	// create ballots to test candidate with
	Ballot b1 = new Ballot(1,choices1);
	Ballot b2 = new Ballot(2, choices2);
	
	/**
	 * This tests for both getCurCount() and addVote() methods.
	 * Tests with edge case of 0. First assert tests if
	 * candidate has 0. Then we'll add a ballot to the
	 * candidate, and tests if it is still zero.
	 */
	@Test
	public void testVoteAndCount1() {
		assertEquals(0, cand1.getCurCount());
		cand1.addVote(b1);
		assertEquals(1,cand1.getCurCount());
	}
	/**
	 * Tests if addVote() actually adds the ballot to the
	 * candidate and tests if getCurCount() returns the 
	 * correct number of ballots that belong to the candidate.
	 */
	@Test
	public void testVoteAndCount2() {
		cand1.addVote(b1);
		cand1.addVote(b2);
		// Test if added ballots to candidate
		assertEquals(2, cand1.getCurCount());	
	}
	/**
	 * Tests getName(). Should return the name of the candidate.
	 */
	@Test
	public void testGetName() {
		assertEquals("Terry", cand1.getName());
	}
	/**
	 * Name should be case-sensitive, so that means that lower-case
	 * and upper-case should not be returned or expected.
	 * Tests lower-case
	 */
	@Test
	public void testGetNameLowerCase() {
		//test lowercase
		assertThat("terry", not(equals(cand1.getName())));
	}
	/**
	 * Tests upper-case for getName()
	 */
	@Test
	public void testGetNameUpperCase() {
		//test uppercase
		assertThat("TERRY", not(equals(cand1.getName())));
	}
	/**
	 * Tests the getVotes() method of Candidate. getVotes() returns the ArrayList
	 * member variable of the candidate.
	 * This will test whether the ArrayList will stay
	 * the same as it is added to the Candidate.
	 */
	@Test
	public void testGetVotes() {
		// Create a new ArrayList<Ballot> to use in the assert
		// and test if the votes are equal
		ArrayList<Ballot> arBallot = new ArrayList<Ballot>();
		arBallot.add(b1);
		cand1.addVote(b1);
		assertEquals(arBallot,cand1.getVotes());
	}
	/**
	 * Tests when given multiple ballots in the ballot ArrayList.
	 */
	@Test
	public void testGetVotes1() {
		// Create a new ArrayList<Ballot> to use in the assert
		// and create multiple ballots to be used in the test
		ArrayList<Ballot> arBallot = new ArrayList<Ballot>();
		int[] choices3 = new int[] {0,0,1};
		int[] choices4 = new int[] {3,2,1};
		Ballot b3 = new Ballot(3, choices3);
		Ballot b4 = new Ballot(4, choices4);
		// Adding ballots to the ArrayList<Ballots> and the candidate
		arBallot.add(b1);
		arBallot.add(b2);
		arBallot.add(b3);
		arBallot.add(b4);
		cand1.addVote(b1);
		cand1.addVote(b2);
		cand1.addVote(b3);
		cand1.addVote(b4);
		assertEquals(arBallot,cand1.getVotes());
	}
	/**
	 * Tests whether the candidate did not get the correct
	 * ballot in its ballot ArrayList member variable
	 */
@Test
	public void testGetVotes2() {
		// testing for edge cases
		cand1.addVote(b1);
//		assertNotEquals(new int[] {0,0,0},cand1.getVotes().get(0).getChoices());
//		assertNotEquals(new int[] {-1,0,0},cand1.getVotes().get(0).getChoices());
	}
	/**
	 * This will test the getParty() method of the candidate class.
	 * It tests whether getParty() will return the character representation
	 * of the candidate's party.
	 */
	@Test
	public void testGetParty1() {
		assertEquals('R', cand1.getParty());
	}
	/**
	 * This will test for lower-case character. The candidate's party
	 * should be a capitol letter, and if it is not, the test should fail.
	 */
	@Test
	public void testGetParty2() {
//		assertNotEquals('r', cand1.getParty());
	}
	/**
	 * This will test if the candidate's party's data type. getParty() should return a character
	 * and the candidate's party should be a character. If the method changes the char
	 * into a string, or if the candidate's party was stored as a string,
	 * the test will fail.
	 */
	@Test
	public void testGetParty3() {
//		assertNotEquals("R", cand1.getParty());
	}
	/**
	 * This will test eliminate() and isEliminated() at once,
	 * because they go hand in hand. eliminate() is called on a candidate, and the
	 * isEliminate() should return the bool representing the elimination status
	 * of the candidate.
	 */
	@Test
	// Tests eliminate() and isEliminated()
	public void testEliminate() {
		// eliminate() is called on cand1 to set eliminate to true
		cand1.eliminate();
		//check if eliminate() changed the bool to true
		assertEquals(true, cand1.isEliminated());
		// if the first assert passed, this assert should pass
	}
	/**
	 * This will test isEliminated().
	 * The eliminate() is not called on the candidate so
	 * the eliminated boolean should be false by default.
	 * This test will check if the candidate is not eliminated. 
	 */
	@Test
	public void testIsEliminated() {
		assertEquals(false, cand1.isEliminated());
	}
}

