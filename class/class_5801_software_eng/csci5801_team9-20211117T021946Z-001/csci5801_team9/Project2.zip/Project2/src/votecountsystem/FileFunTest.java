package votecountsystem;

import static org.junit.Assert.*;
import org.junit.Test;
import java.io.IOException;


/**
 * @author Rohan Abraham
 * @version 1.0
 *
 */

/**
 * 
 * This class ensures that files can be appended to other files and the ballot count can be changed.
 * I used txt files for ease of use, but in practice it will process csv files in the same way.
 *
 */
public class FileFunTest {
	
    //  Test uses  .txt files, but works the same as .csv, testing is just a little nicer with a .txt file
	
	/**			
	 * Tests the ballot count function. Given a file and the line number it will
	 * return a string saying how many ballots are in the file.
	 * @throws IOException if file reading fails
	 */
	@Test
	public void test0() throws IOException {
		FileFun fun = new FileFun();	
		
		// resets the contents of the files
		fun.fileRevert("testing/file1.txt", withOPL);
		fun.fileRevert("testing/file6.txt", withIR);
				
			
				
		//Tests an opl and ir file
		String result1 = fun.ballotCount("testing/file1.txt", 5);
		String expect1 = "100";
		String result2 = fun.ballotCount("testing/file6.txt", 4);
		String expect2 = "40";
				
		assertEquals(expect1, result1);				
		assertEquals(expect2, result2);		
	}
	
	/**			
	 * A little different than the count ballot function. This simply counts the lines
	 * in a file. This is used when a file of ballots is given where the amount of ballots
	 * in it is not specified. 
	 * @throws IOException if file reading fails
	 */
	@Test
	public void test1() throws IOException {
				
		FileFun fun = new FileFun();		
		
		//Tests an opl and unformatted file
		int result1 = fun.countLines("testing/file1.txt");
		int expect1 = 10;
		int result2 = fun.countLines("testing/file3.txt");
		int expect2 = 5;
				
		assertEquals(expect1, result1);				
		assertEquals(expect2, result2);		
	}
	
	/**			
	 * Tests the most important function that given a file will repeatedly
	 * add ballots to it and change the ballot count. ir and po files
	 * will work the same so only ir and opl is tested.
	 * @throws IOException if file reading fails
	 */
	@Test
	public void test2() throws IOException {
				
		FileFun fun = new FileFun();		
		
		String[] oplFiles = {"testing/file1.txt", "testing/file2.txt"};
		String[] irFiles = {"testing/file6.txt", "testing/file3.txt"};
	
				
		//Tests an opl and ir file
		String result1 = fun.fileLoop(oplFiles, "OPL");
		String expect1 = "OPL";
		String result2 = fun.fileLoop(irFiles, "IR");
		String expect2 = "IR";
				
		assertEquals(expect1, result1);				
		assertEquals(expect2, result2);		
	} 
	
	/**			
	 * Test to make sure that when a file is added to another that the ballot count
	 * in the original can be adjusted accordingly. 
	 * @throws IOException if file reading fails
	 */
	@Test
	public void test3() throws IOException {
				
		FileFun fun = new FileFun();			
		//Tests an opl file since ir and po behave the same
		String result1 = fun.alterBallotCount("testing/file1.txt",  "testing/file2.txt", "OPL");
		String expect1 = "110";
	
		assertEquals(expect1, result1);				
			
	} 
	
	/**			
	 * Test to make sure that when a file is added to another that the ballot count
	 * in the original can be adjusted accordingly. 
	 * @throws IOException if file reading fails
	 */
	@Test
	public void test4() throws IOException {
				
		FileFun fun = new FileFun();	
		
		//Tests an opl and ir files different behavior here
		String result1 = fun.appendFiles("testing/file1.txt",  "testing/file2.txt");
		String expect1 = "end file 2";
		String result2 = fun.appendFiles("testing/file6.txt",  "testing/file3.txt");
		String expect2 = "END FILE 3";	
	
		assertEquals(expect1, result1);		
		assertEquals(expect2, result2);	
			
	} 
	
	/**			
	 * Tests the function made for testing. Function takes a filename
	 * and a string containing the contents of the original file to revert the file.
	 * Makes things work since I am editing files after every test run.
	 * @throws IOException if file reading fails
	 */
	@Test
	public void test5() throws IOException {
				
		FileFun fun = new FileFun();	
		
		//Tests that the file has been changed correclty 
		String result1 = fun.fileRevert("testing/file5.txt", "Testing, testing, 123.");
		String expect1 = "Testing, testing, 123.";
	
		assertEquals(expect1, result1);		
	}
	
	//Strings of the original file contents
	
	String withOPL = "OPL\r\n"
			+ "5\r\n"
			+ "[Billy,D],[Sandra,I],[Joe,R],[Luke,R],[Isaac,I]\r\n"
			+ "3\r\n"
			+ "100\r\n"
			+ "THis file is fun\r\n"
			+ "La la la\r\n"
			+ "di di da da\r\n"
			+ "do di\r\n"
			+ "END OF FILE 1";
	
	String withIR = "IR\r\n"
			+ "3\r\n"
			+ "Billy (D),Sandra (I),Joe (R)\r\n"
			+ "40\r\n"
			+ "1,2,\r\n"
			+ "1,,2\r\n"
			+ ",1,3";
			

}
