package votecountsystem;

import static org.junit.Assert.*;
import org.junit.Test;
import java.util.*;
import java.io.*;

/**
* @author Isaac Xiong, Luke Chen
*/

/**
 * 
 * Description: This class will be used to test IR.java
 * and its functionality.
 *
 */
public class IRTest {
	// Create instances of IR object to test it's methods and functionality
	static File testFile1 = new File("testing/irTest1.csv");
	static File testFile2 = new File("testing/irTestFile1.csv");
	static File testFile3 = new File("testing/irtest.csv");
	static File testFile4 = new File("testing/irTie.csv");
	
	/**
	 * This is to test the ballot filtering of ballots with less than 50% candidates filled out
	 */
	@Test
	public void testFilter1() {
		IR ir = new IR(testFile1, false);
		ir.runIR();
		assertEquals(5, ir.getBallots() - ir.getBallotIDsAssigned());
	}
	
	/**
	 * This is to test the ballot filtering of ballots with less than 50% candidates filled out
	 */
	@Test
	public void testFilter2() {
		IR ir = new IR(testFile2, false);
		ir.runIR();
		assertEquals(19, ir.getBallots() - ir.getBallotIDsAssigned());
	}
	
	/**
	 * This is to test the ballot filtering of ballots with less than 50% candidates filled out
	 */
	@Test
	public void testFilter3() {
		IR ir = new IR(testFile3, false);
		ir.runIR();
		assertEquals(5, ir.getBallots() - ir.getBallotIDsAssigned());
	}
	
	/**
	 * This is to test the ballot filtering of ballots with less than 50% candidates filled out
	 */
	@Test
	public void testFilter4() {
		IR ir = new IR(testFile4, false);
		ir.runIR();
		assertEquals(7, ir.getBallots() - ir.getBallotIDsAssigned());
	}
	
	/**
	 * This will test if the parse() function correctly parses the number of candidates,
	 * ballots, and parties. The IR constructor calls parse() inside of it.
	 */
	@Test
	public void testParse1() {
		// irtest.csv has 3 candidates (Billy (D), Sandra (I), Joe (R))
		// 40 total votes
		// 3 parties
		// The IR constructor calls parse().
		IR ir = new IR(testFile1, false);
		assertEquals(3, ir.getCandidates());
		assertEquals(40, ir.getBallots());
		assertEquals(3, ir.getParties().length);
	}
	/**
	 * This test will test a csv file with candidates, but zero votes. This should count 
	 * 0 ballots.
	 */
	@Test
	public void testParse2() {
		//testFile3 -> irtest.csv
		// contains 2 candidates, 0 votes, 2 parties
		IR ir = new IR(testFile3, false);
		assertEquals(2, ir.getCandidates());
		assertEquals(0, ir.getBallots());
		assertEquals(2, ir.getParties().length);
	}
	
	/**
	 * This tests the parse with the max number of candidates (10), and 50 ballots, and number of parties
	 * in the parties array.
	 */
	@Test
	public void testParseWithMaxCand() {
		// testFile2 -> irTestFile1.csv
		// contains 10 candidates (max), 50 votes, 10 parties
		IR ir = new IR(testFile2, false);
		assertEquals(10, ir.getCandidates());
		assertEquals(50, ir.getBallots());
		assertEquals(10, ir.getParties().length);
	}
	
	/**
	 * This will test the runIR() method. Billy is the winner of testFile3,
	 * so runIR() should return a string saying Billy won.
	 */
	@Test
	public void testRunIR() {
		IR ir = new IR(testFile3, false);
		String result = "Billy won with 0 votes";
		assertEquals(result, ir.runIR());
	}
	/**
	 * Tests the tieBreaker() method. Should return the number in the arraylist that will
	 * be removed.
	 */
	@Test
	public void testTieBreaker() {
		
		IR ir = new IR(testFile3, false);
		ArrayList<Integer> arrList = new ArrayList<Integer>();
		arrList.add(1);
		assertEquals(ir.tieBreaker(arrList), 1);
	}
	/**
	 * This will test the initialization of the EventLogger in the IR class.
	 * We are creating a new EventLogger object to compare with the EventLogger that is 
	 * created in the IR instance. This will only test for simple member variables that aren't arrays (int)
	 */
	@Test
	public void testInitLogIntegerVariables() {
		String[] names = {"Billy", "Sandra"};
		char[] parties = {'D','I'};
		IR ir = new IR(testFile3, false);
		EventLogger expectedLog = new EventLogger("IR", 2, names, parties, 0, 0);
		EventLogger actualLog = ir.initLog();
		assertEquals(expectedLog.getType(), actualLog.getType());
		assertEquals(expectedLog.getCandidates(), actualLog.getCandidates());
		assertEquals(expectedLog.getNumOfBallots(), actualLog.getNumOfBallots());
		
		assertEquals(expectedLog.getType(), actualLog.getType());
		assertEquals(expectedLog.getType(), actualLog.getType());
	}
	/**
	 * This will test the initialization of the EventLogger in the IR class.
	 * We are creating a new EventLogger object to compare with the EventLogger that is 
	 * created in the IR instance. This will test for each element in the member variables
	 * that are arrays.
	 */
	
	@Test
	public void testInitLogArrayVariables() {
		String[] names = {"Billy", "Sandra"};
		char[] parties = {'D','I'};
		IR ir = new IR(testFile3, false);
		EventLogger expectedLog = new EventLogger("IR", 2, names, parties, 0, 0);
		EventLogger actualLog = ir.initLog();
		// Go through each element in the candidate_names array and see if it matches the expected value
		for (int i = 0; i < actualLog.getEventCandNames().length; i++) {
			assertEquals(expectedLog.getEventCandNames()[i], actualLog.getEventCandNames()[i]);
		}
		// Go through each element in the parties array and see if it matches the expected value
		for (int i = 0; i < actualLog.getParties().length; i++) {
			assertEquals(expectedLog.getParties()[i], actualLog.getParties()[i]);
		}
	}
	
	/**
	 * This will test the eliminate() method in the IR class.
	 * Candidates at initialization should not be eliminated, then as eliminate() is called on
	 * a candidate, the candidate should be eliminated() (the candidate's eliminate boolean turns true). 
	 * This test will test the first two candidates.
	 */
	@Test
	public void testEliminate() {
		// Create instance of IR
		IR ir = new IR(testFile1, false);
		// Candidates are not eliminated at the beginning, therefore, candidate.isEliminated() should be false
		for (int i = 0; i < ir.getCandNames().length; i++) {
			assertEquals(false, ir.getCandNames()[i].isEliminated());
		}

		// call the eliminate() method on the candidates to eliminate the candidate
		for (int i = 0; i < ir.getCandNames().length; i++) {
			ir.eliminate(ir.getCandNames()[i]);
		}
		// candidate.isEliminated() should return true
		for (int i = 0; i < ir.getCandNames().length; i++) {
			assertEquals(true, ir.getCandNames()[i].isEliminated());
		}
	}
	
	/**
	 * This will test the reallocate() method in the IR class.
	 * To test, we will keep track of the Ballot ID that was assigned to Billy (the first candidate),
	 * then we will eliminate Billy, the the ballot will be reallocated to the next candidate.
	 */
	@Test
	public void testReallocate() {
		boolean check = false;
		IR ir = new IR(testFile1, false);
		// This Ballot ID belongs to Billy
		System.out.println(ir.getCandNames().length);
		int expectedBallotID = ir.getCandNames()[0].getVotes().get(0).getID();
		
		// Eliminate Billy
		ir.eliminate(ir.getCandNames()[0]);
		// reallocate the votes that belonged to Billy. We know from the CSV file that this
		// tracked ballot will be reallocated to Sandra. We will go through each of Sandra's
		// ballots to see if the tracked Ballot ID was reallocated correctly.
		ir.reallocate(ir.getCandNames()[0].getVotes());
		//
		for (int i = 0; i < ir.getCandNames()[1].getVotes().size(); i++) {
			if (ir.getCandNames()[1].getVotes().get(i).getID() == expectedBallotID) {
				check = true;
			}
		}
		assertEquals(true, check);
	}
	

}
