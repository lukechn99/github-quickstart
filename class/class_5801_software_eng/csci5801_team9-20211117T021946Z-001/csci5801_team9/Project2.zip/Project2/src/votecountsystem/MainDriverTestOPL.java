package votecountsystem;

import static org.junit.Assert.*;
import org.junit.Test;
import java.io.*;
import org.junit.*;

/**
 * This class is testing giving an input file, such that the first line is OPL
 * and nothing else it also checks to make sure it's not an empty csv file
 */
public class MainDriverTestOPL {

	// calling MainDriver constructor, giving testing file
	MainDriver md = new MainDriver();
	File fileName = new File("testing/opl.csv");

	// reads through the file
	String line = "";
	// retrieves first line
	String typeOfElection = "";

	/**
	 * @throws IOException Also check if the 1st line is an OPL
	 */
	// check if it's OP
	@Test
	public void checkOPLAsFirstLine() throws IOException {
		md.readInputFile(fileName);
		try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
			line = br.readLine();
		}
		typeOfElection = line.lines().findFirst().get();
		Assert.assertTrue("File is empty", line != null);
		assertEquals("OPL", typeOfElection);

	}

}

