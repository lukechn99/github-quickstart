package votecountsystem;

// import votecountsystem.Event;
import java.util.*;
import java.io.*;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * @author Luke
 * @version 1.0
 */

/**
 * EventLogger class works to track the actions performed during the vote
 * counting
 *
 */
public class EventLogger {
    private ArrayList<Event> events;
    private String type; // IR or OPL
    private int candidates;
    private String[] candidate_names;
    private char[] parties;
    private int ballots;
    private int[] votes_per_party;
    private int[] votes_per_candidate;
    private int seats;

    /**
     * 
     * @return candidates
     */
    public int getCandidates() {
        return candidates;
    }

    /**
     * 
     * @return candidate_names
     */
    public String[] getEventCandNames() {
        return candidate_names;
    }

    /**
     * 
     * @return parties
     */
    public char[] getParties() {
        return parties;
    }

    /**
     * 
     * @return type
     */
    public String getType() {
        return type;
    }

    /**
     * 
     * @return ballots
     */
    public int getNumOfBallots() {
        return ballots;
    }
    
    /**
     * 
     * @return events size
     */
    public int getNumberOfEvents() {
        return events.size();
    }

    /**
     * since the EventLogger is created by either OPL or IR, OPL and IR will not be
     * registered as an event, however, for the creation of an audit or report, OPL,
     * IR, and other so-called "pre-processing" information still needs to be
     * included
     *
     * @param election_type        type of the election
     * @param number_of_candidates is the number of candidates participating
     * @param c_names              the names of the candidates in order
     * @param party_names          array of parties, corresponding to the candidates
     *                             in c_names
     * @param number_of_ballots is the number of ballots being counted
     * @param number_of_seats is the number of seats run with, only relevant for OPL
     */
    public EventLogger(String election_type, int number_of_candidates, String[] c_names, char[] party_names,
            int number_of_ballots, int number_of_seats) {
        type = election_type;
        candidates = number_of_candidates;
        candidate_names = c_names;
        parties = party_names;
        ballots = number_of_ballots;
        seats = number_of_seats;
        events = new ArrayList<Event>();
    }

    /**
     * Because initialization of the log is done before the parsing, the log does
     * not actually contain the correct info. After parsing, the system has the
     * correct information so we need to set the information again
     *
     * @param number_of_candidates 	number of candidates
     * @param c_names				names of the candidates
     * @param party_names			names of the parties
     * @param number_of_ballots		number of ballots in election
     */
    public void set(int number_of_candidates, String[] c_names, char[] party_names, int number_of_ballots) {
        candidates = number_of_candidates;
        candidate_names = c_names;
        parties = party_names;
        ballots = number_of_ballots;
    }

    /**
     * Sets the votes each party received corresponding to the party
     * @param number_votes number of votes per party for OPL
     */
    public void reportPartyVotes(int[] number_votes) {
        votes_per_party = number_votes;
    }

    /**
     * Sets the votes each candidate received corresponding to the candidate
     * @param number_votes number of votes per candidate
     */
    public void reportCandidateVotes(int[] number_votes) {
        votes_per_candidate = number_votes;
    }

    /**
     * This method creates a file with the audit title and time and then iterates
     * through the events ArrayList to write to file every event that happened
     * during the vote count. The print style of the event needs to be different
     * according to the type of event it is. I am not at all sure how to do an audit
     * log in CSV except to dedicate a column to "candidate", "ballot", and "action"
     *
     * @return a string representation of the audit log
     */
    public String generateAudit() {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM_dd_HH_mmss");
        LocalDateTime now = LocalDateTime.now();
        File file = new File(type + "_audit_" + dtf.format(now) + ".csv");
        String audit = "";
        try {
            FileWriter writer = new FileWriter(file, true);
            writer.write("This vote was of type " + type + "\n");
            audit += "This vote was of type " + type + "\n";
            writer.write("It ran with " + Integer.toString(candidates) + " candidate(s)" + "\n");
            audit += "It ran with " + Integer.toString(candidates) + " candidate(s)" + "\n";
            writer.write("A total of " + Integer.toString(ballots) + " ballots were cast" + "\n");
            audit += "A total of " + Integer.toString(ballots) + " ballots were cast" + "\n";
            for (int i = 0; i < events.size(); i++) {
                writer.write(events.get(i).toString() + "\n");
                audit += events.get(i).toString() + "\n";
            }
            writer.close();
        } catch (IOException e) {
            System.out.println("Error in file creation");
            e.printStackTrace();
        }
        return audit;
    }

    /**
     * generateReport() will take the general information and create a report that
     * is saved as a file and printed to the console
     *
     * @return a string copy of the report to print to console
     */
    public String generateReport() {
        // TODO: print to a buffer and then print buffer to console and store as file
        String report = "";
        report += "This election was held between " + Integer.toString(candidates) + " candidate(s):\n";
        for (int i = 0; i < candidates; i++) {
            report += candidate_names[i] + ", ";
        }
        report += "\n";
        report += "A total of " + Integer.toString(ballots) + " voters voted.\n";

        if (type == "OPL" && events.size() > seats + candidates) {
        	for (int i = 0; i < seats + candidates; i++) {
        		report += events.get(events.size() - seats - candidates + i) + "\n";
        	}
        }
        if (type == "IR" && events.size() > 0) {
        	report += events.get(events.size() - 1).toString();
        }
        if (type == "PO") {
            for (int i = 0; i < seats + candidates; i++) {
        		report += events.get(events.size() - seats - candidates + i) + "\n";
        	}
        }
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM_dd_HH_mmss");
        LocalDateTime now = LocalDateTime.now();
        File file = new File(type + "_results_" + dtf.format(now) + ".csv");
        try {
            FileWriter writer = new FileWriter(file, true);
            writer.write(report);
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        /**
         * This election was held between 2 candidates Bob, and Ryan A total of 100
         * voters voted. Bob got 10 votes Ryan got 90 votes
         */

        return report;
    }

    /**
     * When the event does not relate to a candidate, "N/A" is used. And when an
     * event does not relate to a ballot, -1 is used. Actions are defined as
     * "eliminate", "declare winner", "distribute", "redistribute", "tiebreaker",
     * etc. Please determine a set of key words and stick to them.
     *
     * @param candidate_name is the candidate involved
     * @param ballot_id      is the ballot involved
     * @param a              is the action that is taking place
     */
    public void addEvent(String candidate_name, int ballot_id, String a) {
        events.add(new Event(candidate_name, ballot_id, a));
    }
}
