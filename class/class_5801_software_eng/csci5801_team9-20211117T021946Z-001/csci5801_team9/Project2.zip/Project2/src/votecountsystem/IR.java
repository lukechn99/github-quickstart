package votecountsystem;

// import java.io.FileNotFoundException;

// import votecountsystem.Ballot;
// import votecountsystem.Candidate;
// import votecountsystem.Event;
// import votecountsystem.EventLogger;
import java.io.*;
import java.util.*;


/**
 * 
 * @author Luke, Isaac
 * @version 1.0
 */

/**
 * 
 * Key features to talk about:
 *
 * Elimination function works by marking candidates as eliminated rather than
 * deleting them. This is so that we don't have to readjust all ballots to
 * account for a deletion
 *
 * Event tracking will center on the Candidate as the main character. Just like
 * how a complete sentence needs a subject and verb, an event should be about a
 * candidate and what happens to the candidate. In approaching this, we need
 * standardized actions (verb) that a Candidate can take or that can be
 * performed on the Candidate
 *
 * Tie breaking will use the indexes of candidate_names, so it is assumed they
 * will not switch around
 *
 */
public class IR {
    private EventLogger log;
    private int candidates;
    private int ballots;
    private int ballotIDsAssigned;
    private Candidate[] candidate_names;
    private char[] parties;
    private boolean shuffle;

    /**
     * Getters for member variables
     */
    /**
     * 
     * @return candidates
     */
    public int getCandidates() {
        return candidates;
    }

    /**
     * 
     * @return ballots
     */
    public int getBallots() {
        return ballots;
    }
    
    /**
     * 
     * @return ballotIDsAssigned 
     */
    public int getBallotIDsAssigned() {
    	return ballotIDsAssigned;
    }

    /**
     * 
     * @return parties
     */
    public char[] getParties() {
        return parties;
    }

    /**
     * 
     * @return candidate_names
     */
    public Candidate[] getCandNames() {
        return candidate_names;
    }

    /**
     * creates an IR class object to run an IR election
     * 
     * @param filename is the csv
     * @param s        is the shuffle variable
     */
    public IR(File filename, boolean s) {
        initLog();
        try {
            parse(filename);
        } catch (IOException e) {
            e.printStackTrace();
        }
        String[] names = new String[candidates];
        for (int i = 0; i < candidates; i++) {
            names[i] = candidate_names[i].getName();
        }
        log.set(candidates, names, parties, ballots);
    }

    /**
     * parse will take a CSV file and parse the information while simultaneously
     * creating the data structures to support vote counting later on
     *
     * @param fname is the name of the file to parse
     * @throws IOException when the parsing goes wrong
     */
    public void parse(File fname) throws IOException {
        Scanner scanner = new Scanner(fname);

        // go to the second line in CSV to get candidates
        scanner.nextLine(); // returns IR, goes to number of candidates
        candidates = Integer.parseInt(scanner.nextLine()); // sets candidates to number of candidates, goes to list
                                                           // of candidate names and parties

        // initialize arrays to the number of candidates
        candidate_names = new Candidate[candidates];
        parties = new char[candidates];

        // once at line with list of candidates, check each token and set into
        // respective array
        String namesOfCandidates = scanner.nextLine().replaceAll(",", ", ");

        System.out.println("String of candidate names: " + namesOfCandidates);
        String[] candidateTokens = namesOfCandidates.split(" ");
        for (int i = 0; i < candidateTokens.length; i++) {
            // String line = scanner.next().replaceAll(",", ", ");
            if (i % 2 == 0) {
                String cname = candidateTokens[i]; // get candidate name
                // System.out.println(cname);
                char partyName = candidateTokens[i + 1].charAt(1); // get candidate's party
                candidate_names[i / 2] = new Candidate(cname, partyName);
                parties[i / 2] = partyName;
            }
        }
        initLog();
        // assuming after setting candidate and party arrays, scanner will be set to #
        // of ballots
        ballots = Integer.parseInt(scanner.nextLine()); // set ballots to the number of ballots in the file, set
                                                        // scanner to first actual votes
        int ballotId = 1;
        int numberEliminated = 0;
        while (scanner.hasNextLine()) { // while lines of votes exist
            int ballotChoices[] = new int[candidates];
            int primary_vote = 0;
            String vote = scanner.nextLine().replaceAll(",", ", ");
            String[] vote_arr = vote.split(" ");
            int i = 0;
            int empty_slots = 0;
            while (i < vote_arr.length) {
                if (!vote_arr[i].equals(",")) {
                    ballotChoices[i] = Integer.parseInt(vote_arr[i].replace(",", ""));
                    if (ballotChoices[i] == 1) {
                        primary_vote = i;
                    }
                } else {
                    empty_slots++;
                }
                i++;
            }
            if (empty_slots > candidates / 2) {
            	numberEliminated++;
                log.addEvent("N/A", -1, "ballot discarded");
            } else {
                Ballot newBallot = new Ballot(ballotId, ballotChoices);
                log.addEvent("N/A", newBallot.getID(), "added to system");
                candidate_names[primary_vote].addVote(newBallot);
                // log the first allocation
                log.addEvent(candidate_names[primary_vote].getName(), newBallot.getID(), "given");
                ballotId++;
            }
        }
        ballotIDsAssigned = ballotId;
        System.out.println(ballots - ballotId);
        log.addEvent("discarded ", numberEliminated, " ballots");
        scanner.close();
    }

    /**
     * Parses the candidates and other information like number of candidates and
     * ballots in the same manner as parse() above. shuffleParse() parses ballots
     * and creates the ballot object and then shuffles before distributing to
     * candidates
     *
     * @param fname file name for shuffling before parsing
     * @throws IOException is called when the IO fails
     */
    public void shuffleParse(File fname) throws IOException {
        // parse candidates and numbers
        Scanner scanner = new Scanner(fname);
        scanner.nextLine();
        candidates = Integer.parseInt(scanner.nextLine());
        candidate_names = new Candidate[candidates];
        parties = new char[candidates];
        for (int i = 0; i < candidates; i++) {
            String cname = scanner.next();
            char pname = scanner.next().charAt(1);
            candidate_names[i] = new Candidate(cname, pname);
            parties[i] = pname;
        }

        // parse ballots
        scanner.nextLine();
        ballots = Integer.parseInt(scanner.nextLine());
        ArrayList<Ballot> ballot_buffer = new ArrayList<Ballot>();
        int ballotId = 1;
        while (scanner.hasNextLine()) {
            int ballotChoices[] = new int[candidates];
            String vote = scanner.nextLine().replaceAll(",", ", ");
            String[] vote_arr = vote.split(" ");
            for (int i = 0; i < vote_arr.length; i++) {
                if (!vote_arr[i].equals(",")) {
                    ballotChoices[i] = Integer.parseInt(vote_arr[i].replace(",", ""));
                }
            }
            Ballot newBallot = new Ballot(ballotId, ballotChoices);
            ballot_buffer.add(newBallot);
            ballotId++;
        }
        // shuffle ballots
        int[] shuffled_order = new int[candidates];
        int beg = 0;
        int end = ballots - 1;
        int index = 0;
        Random r = new Random();
        while (beg < end) {
            if (r.ints(0, 2).findFirst().getAsInt() == 1) {
                shuffled_order[index] = beg;
                beg++;
            } else {
                shuffled_order[index] = end;
                end--;
            }
            index++;
        }

        // distribute
        for (int i = 0; i < shuffled_order.length; i++) {
            Ballot b = new Ballot(ballot_buffer.get(shuffled_order[i]));
            log.addEvent("N/A", b.getID(), "added to system");
            int candidate_destination = b.getNthChoice(1);
            candidate_names[candidate_destination].addVote(b);
            log.addEvent(candidate_names[candidate_destination].getName(), b.getID(), "given");
        }
        scanner.close();
    }

    /**
     * An ArrayList of the indexes of tied candidates are input, coin flips are done
     * to remove candidate indexes from the list. Being removed guarantees that they
     * will NOT be eliminated. The last candidate in the list is eliminated
     *
     * @param tied_candidates the list of tied candidates by index
     * @return the index to be eliminated
     */
    public int tieBreaker(ArrayList<Integer> tied_candidates) {
        Random r = new Random();
        int coin;
        while (tied_candidates.size() > 1) {
            // either remove the first candidate, or the second based on coin flip
            int heads = 0;
            int tails = 0;
            for (int i = 0; i < 1001; i++) {
                coin = r.ints(0, 2).findFirst().getAsInt();
                if (coin == 0) {
                    heads++;
                } else {
                    tails++;
                }
            }
            if (heads > tails) {
                tied_candidates.remove(0);
            } else {
                tied_candidates.remove(1);
            }
        }
        // eliminate the first candidate in the list which should also be the
        // only candidate left
        return tied_candidates.get(0);
    }

    /**
     *
     * @return the winner as a candidate and number of
     */
    public String runIR() {
        boolean ongoing = true;
        int round = 1;
        while (ongoing) {
            int most_popular = 0; // number to compare for majority
            int most_popular_candidate = 0; // index of the most popular
            // count number of ballots per candidate
            for (int i = 0; i < candidates; i++) {
                int votes = candidate_names[i].getCurCount();
                if (votes > most_popular) {
                    most_popular = votes;
                    most_popular_candidate = i;
                }
            }
            // if there is a majority then announce the winner
            if (most_popular > ballots / 2) {
                ongoing = false;
                log.addEvent(candidate_names[most_popular_candidate].getName(), -1, "win");
                // Pair<Candidate, Integer> result = new Pair<Candidate,
                // Integer>(candidate_names[most_popular_candidate],
                // most_popular);
                String result = candidate_names[most_popular_candidate].getName() + " won with "
                        + Integer.toString(most_popular) + " votes";
                log.addEvent(candidate_names[most_popular_candidate].getName(),
                        candidate_names[most_popular_candidate].getCurCount(), "majority win");
                return result;
                // else eliminate the loser
            } else {
                // count remaining qualifying candidates, if == 2, the win by popularity

                // COUNT HERE
                int number_remaining = 0;
                for (int i = 0; i < candidates; i++) {
                    if (!candidate_names[i].isEliminated()) {
                        number_remaining++;
                    }
                }
                if (number_remaining == 2) {
                    ArrayList<Integer> winners = new ArrayList<>();
                    for (int i = 0; i < candidates; i++) {
                        if (!candidate_names[i].isEliminated()) {
                            winners.add(i);
                        }
                    }

                    if (candidate_names[winners.get(0)].getCurCount() >= candidate_names[winners.get(1)]
                            .getCurCount()) {
                        String result = candidate_names[winners.get(0)].getName() + " won with "
                                + Integer.toString(candidate_names[winners.get(0)].getCurCount()) + " votes";
                        System.out.println(result);
                        log.addEvent(candidate_names[winners.get(0)].getName(),
                                candidate_names[winners.get(0)].getCurCount(), "popularity win");
                        return result;
                    } else {
                        String result = candidate_names[winners.get(1)].getName() + " won with "
                                + Integer.toString(candidate_names[winners.get(1)].getCurCount()) + " votes";
                        System.out.println(result);
                        log.addEvent(candidate_names[winners.get(1)].getName(),
                                candidate_names[winners.get(1)].getCurCount(), "popularity win");
                        return result;
                    }
                }
                // potential tie breaker for loser
                // redistribute the loser's ballots

                // find the least voted for candidate that isn't eliminated yet
                int least_popular = -1;
                int least_popular_candidate = -1;
                int first_non_eliminated = 0;
                while (least_popular == -1) {
                    if (!candidate_names[first_non_eliminated].isEliminated()) {
                        least_popular = candidate_names[first_non_eliminated].getCurCount();
                        least_popular_candidate = first_non_eliminated;
                    }
                    first_non_eliminated++;
                }

                // iterate search for the lowest voted qualifying candidate
                for (int i = 0; i < candidates; i++) {
                    if (candidate_names[i].getCurCount() < least_popular && !candidate_names[i].isEliminated()) {
                        least_popular = candidate_names[i].getCurCount();
                        least_popular_candidate = i;
                    }
                }

                // check to see if anyone ties for loser
                ArrayList<Integer> losers = new ArrayList<Integer>(least_popular_candidate);
                for (int i = 0; i < candidates; i++) {
                    if (candidate_names[i].getCurCount() == least_popular && !candidate_names[i].isEliminated()) {
                        losers.add(i);
                    }
                }
                // if there is more than one loser, a tie breaker is needed
                int to_be_eliminated;
                if (losers.size() > 1) {
                    log.addEvent("N/A", -1, "tiebreaker");
                    to_be_eliminated = tieBreaker(losers);
                } else {
                    to_be_eliminated = least_popular_candidate;
                }
                // eliminate calls for redistribution
                log.addEvent(candidate_names[to_be_eliminated].getName(), -1, "Eliminated");
                eliminate(candidate_names[to_be_eliminated]);
            }
            System.out.println("at the end of round " + Integer.toString(round));
            for (int i = 0; i < candidates; i++) {
                if (!candidate_names[i].isEliminated()) {
                    System.out.println(candidate_names[i].getName() + " has "
                            + Integer.toString(candidate_names[i].getCurCount()));
                }
            }
            round++;
        }
        return "error";
    }

    /**
     * init eventlogger with the stats of the election in progress
     * 
     * @return returns an eventlogger for testing purposes
     */
    public EventLogger initLog() {
        String[] names = new String[candidates];
        for (int i = 0; i < candidates; i++) {
            names[i] = candidate_names[i].getName();
        }
        log = new EventLogger("IR", candidates, names, parties, ballots, 0);
        return log;
    }

    /**
     * @return EventLogger
     */
    public EventLogger getLog() {
        return log;
    }

    /**
     * marks the candidate as eliminated, so that ballots will not be redistributed
     * to them.
     *
     * @param candidate to be eliminated
     */
    public void eliminate(Candidate candidate) {
        // takes the candidate's ballots and redistributes them
        reallocate(candidate.getVotes());
        // marks the candidate's param as eliminated
        candidate.eliminate();
        log.addEvent(candidate.getName(), -1, "eliminated");
    }

    /**
     * reallocate() takes a copy of the ballots that belonged to an eliminated
     * candidate and distributes them to their next choice will considering the
     * cases outlined below
     *
     * Case 1: Ballot has next and redistributes
     *
     * Case 2: Ballot has next candidate, but the candidate is eliminated
     *
     * Case 3: Ballot does not have next candidate and needs to be discarded 2
     *
     * @param ballots to be reallocated
     */
    public void reallocate(ArrayList<Ballot> ballots) {
        // deep copy
        for (int i = 0; i < ballots.size(); i++) {
            Ballot ballot = new Ballot(ballots.get(i));
            // see what choice we are on (1st, 2nd, 3rd, etc.)
            boolean redistributed = false;

            while (!redistributed) {
                boolean next_uneliminated = true;
                ballot.incrementRound();
                int cur_choice = ballot.getRound();
                // see if the voter placed a vote on that level
                // if the vote does not exist, ex. voter voted for 1,2,,,
                // and the current choice is 3rd, then nothing will happen
                // and the ballot will be thrown away when reallocate()
                // returns to eliminate() and eliminate() ends, ballots
                // will be garbage collected.
                for (int j = 0; j < candidates; j++) {
                    // choices = [1, 0, 0, 2, 0, 3]
                    if (ballot.getChoices()[j] == cur_choice) {
                        // only distributes the ballot to a candidate not eliminated
                        if (!candidate_names[j].isEliminated()) {
                            candidate_names[j].addVote(ballot);
                            redistributed = true;
                            // log
                            log.addEvent(candidate_names[j].getName(), ballot.getID(), "redistribute");
                        } else {
                            // eliminated, so we move back to advance and move onto the next candidate round
                            // already eliminated");
                            next_uneliminated = false;
                            break;// break advance;
                        }
                    }
                }
                if (!redistributed && next_uneliminated) {
                    // log (thrown away)
                    ballots.remove(i);
                    redistributed = true;
                    log.addEvent("N/A", ballot.getID(), "discard");
                }
            }
        }
    }
}
