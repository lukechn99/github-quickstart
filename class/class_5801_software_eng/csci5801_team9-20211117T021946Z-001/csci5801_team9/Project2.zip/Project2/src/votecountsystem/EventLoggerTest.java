package votecountsystem;

import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.Before;

/**
 * Class name: EventLoggerTest
 * @author Luke Chen
 * Description: This class will test the EventLogger class and it's functionality.
 */
public class EventLoggerTest {
	Event event1, event2, event3;
	EventLogger log;
	
	
	/**
	 * Creates an event logger
	 */
	@Before
	public void setup() {
		String[] names = {"John"};
		char[] parties = {'I'};
		log = new EventLogger("OPL", 1, names, parties, 3, 0);
	}
	/**
	 * Tests an empty log
	 */
	@Test
	public void testEmpty() {
		assertEquals(0, log.getNumberOfEvents());
	}
	
	/**
	 * Test a non empty log
	 */
	@Test
	public void testNonEmpty() {
		log.addEvent("John", 1, "added");
		log.addEvent("N/A", 1, "discarded");
		log.addEvent("John", -1, "win");
		
		assertEquals(3, log.getNumberOfEvents());
	}
	
	/**
	 * Tests the generate report
	 */
	@Test
	public void testGenerateReportOPL() {
		log.addEvent("John", 1, "added");
		log.addEvent("John", 2, "added");
		log.addEvent("John", 3, "added");
		log.addEvent("N/A", 1, "discarded");
		log.addEvent("John", -1, "win");
		
		String expectedreport = "This election was held between 1 candidate(s):\n"
				+ "John, \n"
				+ "A total of 3 voters voted.\n"
				+ "John,no ballot involved,win\n";
		String actualreport = log.generateReport();
		assertEquals(expectedreport, actualreport);
	}
	
	/**
	 * Tests if the report is empty
	 */
	@Test
	public void testGenerateReportEmpty() {
		String[] names = {};
		char[] parties = {};
		EventLogger emptylog = new EventLogger("OPL", 0, names, parties, 0, 0);
		String report = "This election was held between 0 candidate(s):\n"
				+ "\n"
				+ "A total of 0 voters voted.\n";
		assertEquals(emptylog.generateReport(), report);
	}
	
	/**
	 * Tests a report for IR
	 */
	@Test
	public void testGenerateReportIR() {
		String[] names = {"John"};
		char[] parties = {'R'};
		EventLogger irlog = new EventLogger("IR", 1, names, parties, 10, 0);
		irlog.addEvent("John", 1, "added");
		irlog.addEvent("John", 2, "added");
		irlog.addEvent("John", 3, "added");
		irlog.addEvent("John", 4, "added");
		irlog.addEvent("John", 5, "added");
		irlog.addEvent("John", 6, "added");
		irlog.addEvent("John", 7, "added");
		irlog.addEvent("John", 8, "added");
		irlog.addEvent("John", 9, "added");
		irlog.addEvent("John", 10, "added");
		irlog.addEvent("John", -1, "win");
		String report = "This election was held between 1 candidate(s):\n"
				+ "John, \n"
				+ "A total of 10 voters voted.\n"
				+ "John,no ballot involved,win";
		assertEquals(report, irlog.generateReport());
	}
	
	/**
	 * Tests the audit generation
	 */
	@Test
	public void testGenerateAudit() {
		log.addEvent("John", 1, "added");
		log.addEvent("N/A", 1, "discarded");
		log.addEvent("John", -1, "win");
		String audit = "This vote was of type OPL\n"
				+ "It ran with 1 candidate(s)\n"
				+ "A total of 3 ballots were cast\n"
				+ "John,1,added\n"
				+ "no candidate involved,1,discarded\n"
				+ "John,no ballot involved,win\n";
		assertEquals(audit, log.generateAudit());
	}
}

