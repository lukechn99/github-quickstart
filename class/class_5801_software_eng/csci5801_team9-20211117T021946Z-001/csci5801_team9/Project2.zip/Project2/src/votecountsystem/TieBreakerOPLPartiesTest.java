package votecountsystem;

import static org.junit.Assert.*;
import org.junit.Test;
import java.io.*;
import java.util.ArrayList;

/**
 *
 * @author Abdikarim Fareh, Rohan
 * @version v1.0 
 * 
 */

/**
 * 
 * This class tests for parties that have same number of votes. we
 *          are testing when a party has enough candidates and qualify to fill
 *          out the seat we also testing when party do not have a candidate so
 *          that we can distribute the seat to the next party that have enough
 *          candidates
 *
 */
public class TieBreakerOPLPartiesTest {

	File sf = new File("testing/opl2.csv");

	/**
	 * @throws IOException we are testing to select a party randomly
	 */
	@Test
	public void tieBreaker2test() throws IOException {
		OpenParty p = new OpenParty(sf);

		int rr = p.seatsPerParty('R');
		int r = 2;

		int dd = p.seatsPerParty('D');
		int d = 0;
		int d2 = 1;

		int ii = p.seatsPerParty('I');
		int i = 1;
		int i2 = 2;

		// republican
		if (r == rr) {
			assertEquals(r, rr);
		}

		// democratic
		if (d == dd) {
			assertEquals(d, dd);
		}
		if (d2 == dd) {
			assertEquals(d2, dd);
		}

		// democratic
		if (i == ii) {
			assertEquals(i, ii);
		}
		if (i2 == dd) {
			assertEquals(i2, ii);
		}

	}

	/**
	 * @throws IOException we are testing to select a party randomly
	 */
	@Test
	public void tieBreaker2test_2() throws IOException {
		OpenParty p = new OpenParty(sf);
		ArrayList<Character> tie = new ArrayList<>();
		tie.add('D');
		tie.add('R');
		tie.add('I');

		char ch = p.tieBreaker2(tie);

		if (ch == 'D') {
			assertEquals('D', ch);
		}

		if (ch == 'R') {
			assertEquals('R', ch);
		}

		if (ch == 'I') {
			assertEquals('I', ch);
		}

	}

}

