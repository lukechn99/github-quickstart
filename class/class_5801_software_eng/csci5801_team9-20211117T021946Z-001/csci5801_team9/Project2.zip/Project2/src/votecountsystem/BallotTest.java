package votecountsystem;

import static org.junit.Assert.*;
import org.junit.Test;


/**
 * @author Abdikarim
 * @version 1.0
 * 
 */

/**
 * In this test class, we are testing given a ballot Array, associated id, 
 * round/rank and increments. 
 * So, basically we are creating ballot object to make sure we are able to 
 * retrieve their associated ID. Be able to get the correct round/rank during 
 * re-distribution and be able to increment after distribution is performed
 * 
 *
 */
public class BallotTest {
	// Ballot Arrays that represents each line
	int a1 [] = { 1, 2, 3, 4, 5};
	int a2 [] = { 2, 3, 4, 5, 1};
	int a3 [] = { 0, 0, 0, 1, 0};
	int a4 [] = { 0, 1, 0, 0, 0};

	// initializing Ballot obj
	Ballot ballotObj = new Ballot(1, a1);
	Ballot ballotObja2 = new Ballot(2, a2);
	Ballot ballotObja3 = new Ballot(1, a3);
	Ballot ballotObja4 = new Ballot(2, a4);

	/**
	 *  gets the id of the ballotObj
	 */
	@Test
	public void testGetIDBallot() {

		assertEquals(1, ballotObj.getID());
		assertEquals(2, ballotObja2.getID());
		assertEquals(1, ballotObja3.getID());
		assertEquals(2, ballotObja4.getID());
	}

	/** 
	 * testing if the choices are the same
	 * of array given
	 */
	@Test
	public void testGetChoiceAsArray() {
		assertArrayEquals(new int[] { 1, 2, 3, 4, 5}, ballotObj.getChoices());
		assertArrayEquals(new int[] { 2, 3, 4, 5, 1}, ballotObja2.getChoices());
		assertArrayEquals(new int[] { 0, 0, 0, 1, 0}, ballotObja3.getChoices());
		assertArrayEquals(new int[] { 0, 1, 0, 0, 0}, ballotObja4.getChoices());
	}


	/**
	 *  this return nth choice. For example, a ballot that has a choice
	 *  {1,2,3,4,5,6}. getNth(2) will return index index of number 2
	 *   which in this case is index 1
	 */
	@Test
	public void testGetIndexOFNthChoice() {
		// [ 1, 2, 3, 4, 5, 6 ]
		// [ 10, 20, 30, 40, 50, 60 ]
		//[ 100, 200, 300, 400, 500, 600 ]

		int n1 = ballotObj.getNthChoice(2);
		int n2 = ballotObja2.getNthChoice(5);
		int n3 = ballotObja3.getNthChoice(1);
		int n4 = ballotObja4.getNthChoice(1);

		assertEquals(1, n1);
		assertEquals(3, n2);
		assertEquals(3, n3);
		assertEquals(1, n4);
	}

	/**
	 *  round is 1 for the 1st round since we doign with one round
	 */
	@Test
	public void testRound() {
		assertEquals(1, ballotObj.getRound());
		assertEquals(1, ballotObja2.getRound());
		assertEquals(1, ballotObja3.getRound());
		assertEquals(1, ballotObja4.getRound());
	}

	/**
	 *  increment adds 1 to round, and round should be 2
	 */
	@Test
	public void test2ndRound() {
		ballotObj.incrementRound();
		assertEquals(2, ballotObj.getRound());
		// again increment to test if it's 3 
		ballotObja2.incrementRound();
		assertEquals(2, ballotObj.getRound());

		ballotObja3.incrementRound();
		assertEquals(2, ballotObj.getRound());

		ballotObja4.incrementRound();
		assertEquals(2, ballotObj.getRound());
	}
	
	
	
	
	

}