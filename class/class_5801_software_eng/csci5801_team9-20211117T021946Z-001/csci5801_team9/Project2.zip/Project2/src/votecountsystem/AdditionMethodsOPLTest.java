package votecountsystem;

import static org.junit.Assert.*;

import org.junit.Test;

//package votecountsystem;

import static org.junit.Assert.assertEquals;
import java.io.*;
import java.util.*;
import org.junit.Test;

/**
 * @author Abdikarim Fareh, Rohan
 * @version v1.0 
 * 
 */

/**
 * These are additional methods I added after project in order to
 *          do the tie breaker I have a method that returns a party given a
 *          name. am also testing another method given a party, give me their
 *          votes in a Desc order testing another method that return list of
 *          candidates given a party Lastly, am testing last method to return
 *          number of seats given a party
 *
 */
public class AdditionMethodsOPLTest {

	File sf = new File("testing/opl2.csv");
	File sff = new File("testing/opl3.csv");

	/**
	 * @throws IOException if file not found. it should give the corrent party
	 *                     provided a candidate name
	 */
	@Test
	public void givenNameGetPartytest() throws IOException {

		OpenParty p1 = new OpenParty(sf);

		char p = p1.givenNameGetParty("Luke");
		char pAnswer = 'R';
		char p2 = p1.givenNameGetParty("Isaac");
		char p2Answer = 'I';

		assertEquals(pAnswer, p);
		assertEquals(p2Answer, p2);

	}

	/**
	 * @throws IOException given a party, give me their votes in a Desc order
	 */
	@Test
	public void helperVotestest() throws IOException {

		OpenParty p = new OpenParty(sf);

		ArrayList<Integer> llR = new ArrayList<>();
		ArrayList<Integer> llR2 = new ArrayList<>();
		llR2.add(25);
		llR2.add(18);

		ArrayList<Integer> llD = new ArrayList<>();
		ArrayList<Integer> llD2 = new ArrayList<>();
		llD2.add(16);

		ArrayList<Integer> llI = new ArrayList<>();
		ArrayList<Integer> llI2 = new ArrayList<>();
		llI2.add(21);
		llI2.add(20);

		llR = p.helperVotes('R');
		llD = p.helperVotes('D');
		llI = p.helperVotes('I');

		assertEquals(llR2, llR);
		assertEquals(llD2, llD);
		assertEquals(llI2, llI);

	}

	/**
	 * @throws IOException provides number of candidates given party
	 */
	@Test
	public void numberOfCandidatesGivenPartytest() throws IOException {

		OpenParty p1 = new OpenParty(sf);

		int n = p1.numberOfCandidatesGivenParty('D');
		int n1 = p1.numberOfCandidatesGivenParty('R');
		int n2 = p1.numberOfCandidatesGivenParty('I');

		// republican
		assertEquals(2, n1);

		// if D is 0
		if (n == 0) {
			assertEquals(0, n);

		}
		if (n == 1) {
			assertEquals(1, n);
		}

		if (n2 == 2) {
			assertEquals(2, n2);
		}

		if (n2 == 1) {
			assertEquals(1, n2);
		}

	}

	/**
	 * @throws IOException provides number of seat for each party
	 */
	@Test
	public void seatsPerPartytest() throws IOException {

		OpenParty p2 = new OpenParty(sff);

		// number of seats for D
		int d = 1;
		int dd = p2.seatsPerParty('D');

		// number of seats for I
		int i = 1;
		int ii = p2.seatsPerParty('I');

		// number of seats for R
		int r = 2;
		int rr = p2.seatsPerParty('R');

		assertEquals(d, dd);
		assertEquals(i, ii);
		assertEquals(r, rr);
	}

}

