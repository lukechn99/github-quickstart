package votecountsystem;

import java.io.*;
import java.nio.file.Files;
import java.util.*;

/**
 *
 * @author Isaac Xiong and Abdikarim Fareh
 * @version v1.0
 *
 */

/**
 * 
 * This class reads a csv file that has been identified as "PO" input file.
 * It parses through the csv and retrieves all the information like candidates,
 * 	 parties, number of ballots.
 * The program goes through and creates Candidate [] Object for candidate names
 * It also associates their parties as well.
 *
 * The program reads all Ballots and assigns each Ballot to a candidate once.
 * It also counts their vote as we go through ballot one at a time.
 *
 *
 * Finally the winner is announced. We log every action that is performed.
 *
 */
public class PO {
    // Initialize global variables to be used in PO
	private EventLogger log ;
	private Candidate [] candidate_names;
	private char [] parties;
	ArrayList<Candidate> mostPopular = new ArrayList<Candidate>();
	private int numberOfCandidates;
	private int numberOfBallots;
	private int numberOfParties;
	int [] arrayBallotVotesPerLine;
	int count = 1;
	
	// this is to track how many votes do each candidate has
	// since we only need to touch the Ballot once, we need to keep track of it
	Map<String, Integer> votecounter = new HashMap<>();

	// this will help us to identify total number of votes per party
	private Map<Character, Integer> partyVotes = new HashMap<>();


	//keep track of how many seats will each party get

	// this one keep tracks of total votes cast
	// we can also use number of Ballots,
	int totalVoteCast = 0 ;

	/**
	 * Takes a filename as a constructor and decides the election base
	 * on popularity alone
	 * @param fileName of file to be run for election
	 * @throws IOException if file not found
	 */
    public PO(File fileName) throws IOException {
		// initializing my log method
		initLog();

		// save the entire text as a List
    	// will this going to fail to read 100, 000
		List<String> ls = Files.readAllLines(fileName.toPath());

		// get token of candidate line

		numberOfCandidates = Integer.parseInt(ls.get(1));
		String lsOfCandidate = ls.get(2);
		numberOfBallots = Integer.parseInt(ls.get(3));
		//numberOfParties = Integer.parseInt(ls.get(3));


		// read the candidate names' line and split them by
		// each square box
		String[] ar = lsOfCandidate.trim().split("],");

		// initialize array length
		String[] candidateName = new String[numberOfCandidates];
		String[] partyChoice = new String [numberOfCandidates];

		//initializing my array char && Candidate object to the length of
		// how many candidate we have
		candidate_names = new Candidate [numberOfCandidates];
		parties = new char [numberOfCandidates];

		for (int i = 0; i < ar.length; i++) {
			String [] arCopy = ar[i].trim().split(",");
			candidateName [i] = arCopy[0].replace("[","");
			partyChoice [i] = arCopy[1].replace("]", "");

			parties [i] = partyChoice [i].charAt(0);
			candidate_names[i]  = new Candidate(candidateName[i],parties [i]);

			// I will use this to keep track of candidate's votes
			votecounter.put(candidateName[i], 0);
			partyVotes.put(parties[i], 0);

			// log that a candidate was found and created
			log.addEvent(candidateName[i], -1, "Creation of new Candidate");
		}

		initLog();

		for ( int i = 0; i < candidate_names.length; i++) {
			System.out.println("Index "+ i + " Candidate Name :" + candidate_names[i].getName() + " party : "+candidate_names[i].getParty());
		}

		// given a string of "01000"
		// get ballot array per line as an new int [] {0,1,0,0, 0}
		System.out.println("list: " + ls);
		createBallotArrayPerLine(ls);

		 // party numbers
		 for ( String s : votecounter.keySet()) {
			 System.out.println("Name " + s + " Has " + votecounter.get(s));
		 }

		 System.out.println();

		 //print statement for candidate votes
		 for ( char s : partyVotes.keySet()) {
			System.out.println("Party " + s + " Has total votes of " + partyVotes.get(s));
		 }

		 System.out.println();

		 System.out.println("Total Vote Casted : " + totalVoteCast);

		 System.out.println();

		// just using for debugging purposes
		// below signature finds out number of seats each party should get
		
		 eventActionToGenerateReportCandidateVotes() ;
		 eventActionToGenerateReportPartyVotes();

	}

    /**
	 *
	 * @param ls takes List of String from the input file to parse through the ballots
	 * @return returns the array of ints that represent ballots
	 */
	public int[] createBallotArrayPerLine( List<String> ls) {
		// the ballot will always start at line number k
		// where k is 4 all the way to end of the list
		if (numberOfBallots > 0) {
			for ( int k = 4; k < ls.size(); k++) {
				// receive each line and place 0 if there is nothing
				String input = ls.get(k).trim().replaceAll(",","0");
	
				// Initializing Ballot size per line
				arrayBallotVotesPerLine = new int [input.length()];
	
				for (int p = 0; p < input.length(); p++) {
					arrayBallotVotesPerLine[p] = Character.getNumericValue(input.charAt(p));
				}
	
				// now is the time we need to find the candidate it belongs to
				// and assigned to them
				assigningBallotTocandidate(arrayBallotVotesPerLine);
			}
		}
		return arrayBallotVotesPerLine;
	}

    /**
	 *
	 * This is a helper function that will receive a Ballot ( continuously )
	 * and assigns to a candidate if that ballot has a at least a vote
	 * As we assign ballots to candidate, we also counting their votes
	 * @param arrayBallotVotesPerLine2 assigns votes to candidate
	 * @return the candidate name
	 */
	public String assigningBallotTocandidate(int[] arrayBallotVotesPerLine2) {
		Ballot ballotObj;

		// get the index of 1, and associate with it's owner ( a candidate )
		// {1,0,0,0,0}  it will return index 0
		 int keeper = returnIndex(arrayBallotVotesPerLine2);

		 if (keeper >= 0) {
			// create a Ballot object Ballot ( count, arrayBalotVotesperline2, candidate_name[keep].getparty)
			ballotObj = new Ballot(count, arrayBallotVotesPerLine2);
			candidate_names[keeper].addVote(ballotObj);

			// ballot is assigned to a candidate
			log.addEvent(candidate_names[keeper].getName(), ballotObj.getID(), " is assigned to a candidate");
			// keep track of candidates vote
			votecounter.put(candidate_names[keeper].getName(), votecounter.get(candidate_names[keeper].getName())+1);

			// keep track of parties' total vote
			partyVotes.put(candidate_names[keeper].getParty() , partyVotes.get(candidate_names[keeper].getParty())+1);

			// I need to log an event

			// number of ballots created ;
			count++;

			// Increment total vote cast
			totalVoteCast++;
			return candidate_names[keeper].getName();
		 } else {
			// when the Ballot has nothing (0,0,0,0,0 based on the candidate)
			log.addEvent("No candidate", count, " Discarded ");
			return "No candidate";
		 }
	}

    /**
	 *
	 * @param bArray takes in Array of Ballot
	 * @return helper function to return where there is "1" in a ballot
	 * so that we can assigned to the intended candidate
	 */
	public int returnIndex (int [] bArray) {
		for (int i = 0 ; i < bArray.length; i++) {
			if ( bArray [i] == 1 ) {
				return i;
			}
		}
		return -1;
	}

	/**
	*  Run the PO election and determine a single winner based on the
	*  candidate with the most amount of votes.
	*  @return String that contains the winner
	*/
    public String runPO() {
		boolean tie = true;
		int mostCurVotes = -1;
        // go through the candidates and find the most amount of votes given to any candidate
		// then place each candidate in the Array List
		for (int i = 0; i < candidate_names.length; i++) {
			if (candidate_names[i].getCurCount() > mostCurVotes) {
				mostCurVotes = candidate_names[i].getCurCount();
			}
		}
	
		// go through the Array List and remove the candidates that do not have the most amount of votes at a time
		for (int i = 0; i < candidate_names.length; i++) {
			if (candidate_names[i].getCurCount() < mostCurVotes) {
				candidate_names[i] = null;
			}
		}
		// add the candidates with the most popular amount of votes into an ArrayList<Candidate>
		// so that candidates can be easily removed if there needs to be a tie breaker
		for (int i = 0; i < candidate_names.length; i++) {
			if (candidate_names[i] != null) {
				mostPopular.add(candidate_names[i]);
			}
		}
		// call tieBreaker if there are ties between candidates
		while (tie) {
			if (mostPopular.size() == 1) {
				tie = false;
			} else {
				tieBreaker(mostPopular);
			}
		}
		
		return "Winner is " + mostPopular.get(0).getName();
    }

	/**
	*  If there is a tie between candidates, flip a coin 1000 times and remove a candidate based on the
	*  coin toss.
	*  @param candidates an ArrayList that contains the candidates that are tied in the election
	*  @return return the updated ArrayList with the removed candidates from the tie breaker
	*/
	public ArrayList<Candidate> tieBreaker(ArrayList<Candidate> candidates) {
		Random r = new Random();
        int coin;
		while (candidates.size() > 1) {
			int heads = 0;
            int tails = 0;
            for (int i = 0; i < 1001; i++) {
                coin = r.ints(0, 2).findFirst().getAsInt();
                if (coin == 0) {
                    heads++;
                } else {
                    tails++;
                }
            }
            if (heads > tails) {
                candidates.remove(0);
            } else {
                candidates.remove(1);
            }
		}
		log.addEvent(mostPopular.get(0).getName(), mostPopular.get(0).getCurCount(), " Winner");
		return candidates;
	}

    /**
	 * This is my initLog, it initializes my log as soon as we read candidate line
	 */
	public void initLog() {
        String[] names = new String[numberOfCandidates];
        for (int i = 0; i < numberOfCandidates; i++) {
            names[i] = candidate_names[i].getName();
        }
        log = new EventLogger("PO", numberOfCandidates, names, parties, numberOfBallots, 0);
    }

	/**
	 *
	 * @return all logs that were saved
	 */
    public EventLogger getLog() {
        return log;
    }

    /**
     * report number of votes per candidate to the eventlogger
     */
	public void eventActionToGenerateReportCandidateVotes() {
		int v [] = new int[numberOfCandidates];
		for ( int i = 0; i < candidate_names.length; i++){
			v[i] = candidate_names[i].getCurCount();
		}
		log.reportCandidateVotes(v);
	}

	/**
	 * report number of votes for the entire party to eventlogger
	 */
	public void eventActionToGenerateReportPartyVotes() {
		int n = 0;
		int pv [] = new int[numberOfCandidates];
		for (int j = 0; j < parties.length; j++){
			for ( int i = 0; i < candidate_names.length; i++){
				if (Character.compare(parties[j], candidate_names[i].getParty()) == 0){
					n+= candidate_names[i].getCurCount();
				}
			}
			pv [j] = n;
			n = 0;
		}
		log.reportPartyVotes(pv);
	}
	
	/**
     * @return map with amount of votes for each party
     */    
    public Map<Character, Integer> getPartyVotes() {
		return partyVotes;    	
    }

}