package votecountsystem;

import java.io.*;

/**
 * @author Abdikarim Fareh
 * @version 1.0
 */

/**
 * 
 * This is the class where all classes are ran from.
 *
 */
public class MainDriver {

    /**
     * @param fileName receives a file csv and identifies vote type based on IR
     *             or OPL
     * @throws IOException if file not found
     */
    public void readInputFile(File fileName) throws IOException {

        String ir = "IR";
        String op = "OPL";
        String po = "PO";

        // get the vote type string "OP or IR" from input file
        String voteType;

        // buffered reader
        BufferedReader br = null;
        String line = "";

        try {
            br = new BufferedReader(new FileReader(fileName));
            line = br.readLine();

            // getting 1st line of the testFile.
            voteType = line.lines().findFirst().get();

            // check if it's an OP file
            if (voteType.equals(op)) {
                System.out.println("Now Running OP is being selected to run");
                // this will be where you need to call your function of runOPL
                // runOP(fileName);
                OpenParty p = new OpenParty(fileName);
                p.runOPL();
                // System.out.println(p.runOPL());
                EventLogger log = p.getLog();
                log.generateAudit();
                System.out.println(log.generateReport());

            }
            // check if it's an IR file
            if (voteType.equals(ir)) {
                System.out.println("Now Running IR is being selected to run");
                // this will be where you need to call your function of runIR
                // runIR(fileName);
                IR instance = new IR(fileName, false);
                System.out.println(instance.runIR());
                EventLogger log = instance.getLog();
                log.generateAudit();
                System.out.println(log.generateReport());
            }
            if (voteType.equals(po)) {
                System.out.println("Now Running PO is being selected to run");
                PO pop_instance = new PO(fileName);
                //System.out.println(po.runPO()); -> this is toString()
                pop_instance.runPO();
                EventLogger log = pop_instance.getLog();
                log.generateAudit();
                System.out.println(log.generateReport());
            }

        } catch (FileNotFoundException e) {
            System.out.println("File Not found");
        } finally {
            if (br != null)
                br.close();
        }

    }

    /**
     * Main program to run
     * 
     * @param args is the command-line input
     */
    public static void main(String[] args) {
        MainDriver md = new MainDriver();
        // Project1\repo-Team9
        File sf = new File( "testing/opl1.csv" ); // "..//testing"
        try {
            md.readInputFile(sf);
        } catch (IOException e) {
            System.out.println("no such file");
        }
    }
}