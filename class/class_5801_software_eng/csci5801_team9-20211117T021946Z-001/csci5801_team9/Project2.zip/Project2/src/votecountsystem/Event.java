package votecountsystem;

/**
 * Each event holds descriptors for what took place and which candidates or
 * ballots it concerns
 */
public class Event {
    private String candidate;
    private int ballot;
    private String action;

    /**
     * Event actions: For these examples, I use a candidate named Jackie (R) and a
     * ballot with ID 1, use "N/A" or -1 when no candidate or ballot is involved,
     * respectively
     * 
     * "created", can describe a candidate or ballot, add event on creation (ex.
     * Event("Jackie", -1, "created") or Event("N/A", 1, "created"))
     * 
     * "added", describes when a ballot is added to a candidate (ex. Event("Jackie",
     * 1, "added"))
     * 
     * "eliminated", is what happens in IR when a candidate is eliminated and their
     * ballots redistributed (ex. Event("Jackie", -1, ))
     * 
     * "redistributed", is when a ballot is redistributed to a new candidate (ex.
     * for another candidate Event())
     */

    /**
     * what about the case of redistribution?
     * 
     * @param name      must be a candidate name and party in the respective IR or
     *                  OPL format
     * @param ballot_id is the ballot ID, and it -1 when no ballot is involved in
     *                  the event
     * @param a         must be "tie", "eliminate", "win", "distributed",
     *                  "redistributed", "added" for when a candidate is added to
     *                  the system
     */
    public Event(String name, int ballot_id, String a) {
        candidate = name;
        ballot = ballot_id;
        action = a;
    }

    
    /** 
     * @return String
     */
    // toString override for easier audit and reports
    public String toString() {
    	if (ballot == -1) {
    		return candidate + ",no ballot involved," + action;
    	}
    	if (candidate == "N/A") {
    		return "no candidate involved," + Integer.toString(ballot) + "," + action;
    	}
        return candidate + "," + Integer.toString(ballot) + "," + action;
    }
}
