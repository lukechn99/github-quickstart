package votecountsystem;

import java.util.ArrayList;

/**
 * The candidate class represents a candidate with a name and party. The
 * candidate has an elimination status that begins as false. The candidate also
 * owns an arraylist of ballots.
 */
public class Candidate {
    private boolean eliminated;
    private String name;
    private char party;
    private ArrayList<Ballot> votes = new ArrayList<Ballot>();

    /**
     * a candidate has a name and a party along with a votes arraylist that's
     * automatically allocated
     * 
     * @param candidate_name is the name
     * @param candidate_party is the affiliated party
     */
    public Candidate(String candidate_name, char candidate_party) {
        name = candidate_name;
        party = candidate_party;
        eliminated = false;
    }

    /**
     * 
     * @return number of votes the candidate has
     */
    public int getCurCount() {
        return votes.size();
    }

    /**
     * 
     * @return the name of the candidate
     */
    public String getName() {
        return name;
    }

    /**
     * 
     * @return the entire arraylist of votes garnered
     */
    public ArrayList<Ballot> getVotes() {
        return votes;
    }

    /**
     * 
     * @return char candidate's party
     */
    public char getParty() {
        return party;
    }

    /**
     * changes eliminated parameter to true so that no other ballots will be given
     * to this candidate, and then clears the candidate's votes arraylist
     */
    public void eliminate() {
        eliminated = true;
        votes.clear();
    }

    /**
     * 
     * @return boolean elimination status
     */
    public boolean isEliminated() {
        return eliminated;
    }

    /**
     * adds a vote to the candidate's arraylist
     * 
     * @param vote is the vote to be added
     */
    public void addVote(Ballot vote) {
        votes.add(vote);
    }
}