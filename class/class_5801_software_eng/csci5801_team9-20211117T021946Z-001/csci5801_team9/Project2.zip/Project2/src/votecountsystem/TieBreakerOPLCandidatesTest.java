package votecountsystem;

import static org.junit.Assert.*;
import org.junit.Test;
import java.io.*;
import java.util.ArrayList;


/**
 *
 * @author Abdikarim Fareh, Rohan
 * @version v1.0 
 * 			
 */

/**
 * 
 * This class test the functionality of OPL Tie breaker for
 *          Candidates We are testing if there is two candidates that belong to
 *          the same party, that has total number of votes. We break the tie
 *          based on their name and randomly select a winner. We also selecting
 *          candidates based on how many seats are to be filled by the party
 *
 */
public class TieBreakerOPLCandidatesTest {

	File sf = new File("testing/opl3.csv");

	/**
	 * @throws IOException we are testing to select a candidate randomly
	 */
	@Test
	public void tieBreakertest() throws IOException {

		OpenParty p = new OpenParty(sf);

		// Tie Candidates
		ArrayList<String> ll = new ArrayList<>();
		ll.add("Isaac");
		ll.add("Sandra");
		ll.add("Abdikarim");
		ll.add("John");

		// selected individuals
		ArrayList<String> winners = new ArrayList<>();

		// given number of seats
		int numbOfSeats = 2;

		winners = p.tieBreaker(ll, numbOfSeats);

		for (int i = 0; i < winners.size(); i++) {
			if (winners.get(i) == "Isaac") {
				assertEquals("Isaac", winners.get(i));
				System.out.println("Isaac was selected");
			}
			if (winners.get(i) == "Sandra") {
				assertEquals("Sandra", winners.get(i));
				System.out.println("Sandra was selected");
			}
			if (winners.get(i) == "Abdikarim") {
				assertEquals("Abdikarim", winners.get(i));
				System.out.println("Abdikarim was selected");
			}
			if (winners.get(i) == "John") {
				assertEquals("John", winners.get(i));
				System.out.println("John was selected");
			}

		}

	}

	/**
	 * @throws IOException we are testing to select candidates based on how many
	 *                     seats are available
	 */
	@Test
	public void tieBreakertest2() throws IOException {
		OpenParty p1 = new OpenParty(sf);

		ArrayList<String> lll = new ArrayList<>();
		ArrayList<String> win = new ArrayList<>();

		lll = p1.listOFCandidates('I');
		int numbOfSeat = p1.seatsPerParty('I');

		win = p1.tieBreaker(lll, numbOfSeat);

		for (int i = 0; i < win.size(); i++) {
			if (win.get(i) == "Isaac") {
				assertEquals("Isaac", win.get(i));
				System.out.println("Isaac was selected");
			}
			if (win.get(i) == "Sandra") {
				assertEquals("Sandra", win.get(i));
				System.out.println("Sandra was selected");
			}
		}

	}

}

