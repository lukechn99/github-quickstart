package votecountsystem;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;


/**
 * @author Rohan Abraham
 * @version 1.0
 * 
 */


/**
 * 
 * It works by providing a normal election file as a commond line argument followed by a 
 * ballot file. The ballot file has no election info just ballots. 
 *
 */
public class FileFun {

	
	/**
	 * This function is just for testing purposes. It will revert a file back to its original condition after being run.
	 * @param filename is the path of the file to be changed
	 * @param replace is the string to be replaced
	 * @throws IOException when file failure
	 * @return String of replaced file
	 */
	public String fileRevert(String filename, String replace) throws IOException {
		String str = replace;
		BufferedWriter writer = new BufferedWriter(new FileWriter(filename));
		writer.write(str);
		writer.close();
		return replace;
	}
	
	/**
     * Function allows for an election to be ran with multiple files. Takes a base file
     * that is a normal file specifying type of election, number of ballots etc..
     * Then a file of just ballots will be appended onto the end of the base file
     * and the number of ballots listed in the base file will be updated.
     *
     * @param files is a string of filenames to run an election on
     * @param electionType is a string of the type of election to be run
     * @throws IOException is called when the IO fails
     * @return the election type as a string for debugging
     */
	public String fileLoop(String[] files, String electionType) throws IOException {
		for(int i = 1; i < files.length; i++) {
			
				appendFiles(files[0], files[i]); 
				alterBallotCount(files[0], files[i], electionType);
				
			} 
    		
    	
		return electionType;
	}
	
	/**
     * By adding on a number of ballots to the base file the ballot count listed in the base file
     * will have a wrong value. This is crucial because when an election is ran calculations are
     * based on this value in the file. What this does is we have a base file with lets say 100
     * ballots. Then after appending a file of just ballots to the end with 5 ballots the line
     * in the original file listing the amount of ballots will now read 105 instead of 100.
     *
     * @param baseFile is the main file where ballots will be appended to
     * @param ballotFile is a file of just ballots to be appended to the base file
     * @param electionType is a string of the type of election to be run
     * @throws IOException is called when the IO fails
     * @return the new ballotCount of the baseFile that was updated
     */
	public String alterBallotCount(String baseFile, String ballotFile, String electionType) throws IOException {
//		Determine the type of election so that the proper line in the base CSV file listing amount of ballots can be updated
		int lineNumber = 0;
		if(electionType.equals("OPL") == true) {
			lineNumber = 5;
		} else if(electionType.equals("IR") == true) {
			lineNumber = 4;
		} else if (electionType.equals("PO") == true){
			lineNumber = 4;
		} else {			
			System.out.println("Invalid election type");
			lineNumber = -1;
		}
		
//		Get the amount of ballots in the ballotFile and add that to the ballot count in the base file
		int numberOfBallotsBallotFile = countLines(ballotFile);
		String numberOfBallotsBaseFile = ballotCount(baseFile, lineNumber);
		int newBallotCount = Integer.parseInt(numberOfBallotsBaseFile) + numberOfBallotsBallotFile;
		String newBallotCountString = String.valueOf(newBallotCount);
		
		Scanner sc = new Scanner(new File(baseFile));	  
	    StringBuffer buffer = new StringBuffer();
	     
//	    create a copy of the base file in a buffer
	    while (sc.hasNextLine()) {
	        buffer.append(sc.nextLine()+System.lineSeparator());	       
	     }
	     buffer.setLength(buffer.length() - 2); //gets rid of newline so can be run many times without crashing
	     String fileContents = buffer.toString();
	     sc.close();
	     
	     
//	     Replace old ballot count with new ballot count    
	     String oldLine = numberOfBallotsBaseFile;
	     String newLine = newBallotCountString;	     
	     fileContents = fileContents.replaceFirst(oldLine, newLine);
	     
//	     Modify original file with file with updated ballot count
	     FileWriter writer = new FileWriter(baseFile);
	     writer.append(fileContents);
	     writer.flush();
	     writer.close();
	     
	     return newBallotCountString;					
	}
	
	/**
     * Function will simply append a file to the end of the another so that
     * multiple files can easily be run.
     *
     * @param baseFile is the main file where ballots will be appended to
     * @param ballotFile is a file of just ballots to be appended to the base file    
     * @throws IOException is called when the IO fails
     * @return the lastLine of the ballotFile for testing purposes
     */
	public String appendFiles(String baseFile, String ballotFile) throws IOException {
		String lastLine = "lastLineNotSent";
	        try {
//	        Way to append to the baseFile
	        BufferedWriter out = new BufferedWriter(new FileWriter(baseFile, true));
//	        Read in the ballotFile
	        BufferedReader in = new BufferedReader(new FileReader(ballotFile));
	        String string;
	        
	        while ((string = in.readLine()) != null) {	        	
	        	lastLine = string;	        			        	
	            out.write("\n" + string);
	            }
	        in.close();
	        out.close();
	        } catch (IOException e) {
	        }
	        return lastLine;
	       
	    }
	
	/**
     * Function will simply count the amount of lines in the ballotFile.
     * Useful because this value will be added to the line stating how 
     * many ballots there are in the baseFile.
     *
     * @param file is the ballotFile where amount of ballots will be counted
     * @throws IOException is called when the IO fails
     * @return The number of ballots in the ballotFile
     */
	public int countLines(String file) throws IOException {
		int count = 0;
		BufferedReader in = new BufferedReader(new FileReader(file));
		String str = "";
		
	    try {	    	
	    	while ((str = in.readLine()) != null) {
	    		count++;
			        }
		} catch (IOException e) {
			e.printStackTrace();
		}
	        in.close();	      
		
		return count;		
	}
	
	/**
     * Function searches for the number in the baseFile that
     * indicates how many ballots it holds.    
     *
     * @param file is going to be the file that will later be appended to
     * @param lineNumber is the line where the ballot count is listed
     * @throws IOException and issue occurs
     * @return a string in the file for testing
     */
	public String ballotCount(String file, int lineNumber) throws IOException {
		Scanner sc = new Scanner(new File(file));
		String str = "";
		for(int i = 0; i<lineNumber-1; i++) {
			sc.nextLine();
		}
		
		str = sc.nextLine();
		       sc.close();
		       return str;
	}
	
	
	
	
	

}

