package votecountsystem;

import static org.junit.Assert.*;
import org.junit.Test;
import java.io.*;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Rohan Abraham
 * @version 1.0
 *
 */

/**
 * 
 * This testing suite will test all of the functionality within OPL.
 *
 */
public class TestOpenParty {
	// Normal file for testing
	static File testFile1 = new File("testing/opl-1.csv");

	// Strange file with no ballots
	static File testFile2 = new File("testing/oplWithZeroSeats.csv");

	// Strange file with just one ballot and one seat
	static File testFile3 = new File("testing/oplWithOneSeat.csv");

	/**
	 * tests createBallotArrayPerLine function Function will take in a huge list
	 * version of the csv Then the function will then return one of the ballots
	 * represented as an array
	 * @throws IOException if file reading fails
	 */
	@Test
	public void test0() throws IOException {

		OpenParty p1 = new OpenParty(testFile1);
		List<String> list = Files.readAllLines(testFile1.toPath());
		int[] result = p1.createBallotArrayPerLine(list);
		int[] expected = { 0, 0, 0, 0, 1 };

		// Since no ballots this will return null
		OpenParty p2 = new OpenParty(testFile2);
		List<String> list1 = Files.readAllLines(testFile2.toPath());
		int[] result1 = p2.createBallotArrayPerLine(list1);

		// This will return the one ballot that goes towards Billy
		OpenParty p3 = new OpenParty(testFile3);
		List<String> list2 = Files.readAllLines(testFile3.toPath());
		int[] result2 = p3.createBallotArrayPerLine(list2);
		int[] expect2 = { 0, 0, 0, 0, 1 };

		assertArrayEquals(expected, result);
		assertEquals(null, result1);
		assertArrayEquals(expect2, result2);
	}

	/**
	 * Tests the assigningBallotTocandidate function Gives it a ballot and it
	 * returns the name of the candidate that the ballot will be given to
	 * @throws IOException if file reading fails
	 */

	@Test
	public void test1() throws IOException {
		OpenParty p2 = new OpenParty(testFile1);

		List<String> list = Files.readAllLines(testFile1.toPath());
		int[] input = p2.createBallotArrayPerLine(list);

		// Test a real life typical case
		String result1 = p2.assigningBallotTocandidate(input);
		String expect1 = "Isaac";

		// Test a typical manual input case
		String result2 = p2.assigningBallotTocandidate(new int[] { 0, 0, 0, 1, 0 });
		String expect2 = "Luke";

		// Test a manual input where no candidate is given the ballot
		String result3 = p2.assigningBallotTocandidate(new int[] { 0, 0, 0, 0, 0 });
		String expect3 = "No candidate";

		assertEquals(expect1, result1);
		assertEquals(expect2, result2);
		assertEquals(expect3, result3);

	}

	/**
	 * Function tests the identifyNumberOfSeats function Utilize the
	 * getNumberOfVotes function to make sure the function worked properly
	 * @throws IOException if file reading fails
	 */
	@Test
	public void test2() throws IOException {
		// Doesn't call function explicit since function is called in p1 constructor
		OpenParty p1 = new OpenParty(testFile1);
		Map<Character, Integer> result1 = p1.getPartyVotes();
		// Create testing hashmap and fill it with values
		Map<Character, Integer> expect1 = new HashMap<Character, Integer>();
		expect1.put('R', 10);
		expect1.put('D', 26);
		expect1.put('I', 31);

		// Since no ballots this test will return an map with no votes
		OpenParty p2 = new OpenParty(testFile2);
		Map<Character, Integer> result2 = p2.getPartyVotes();
		// Create testing hashmap and fill it with values
		Map<Character, Integer> expect2 = new HashMap<Character, Integer>();
		expect2.put('R', 0);
		expect2.put('D', 0);
		expect2.put('I', 0);

		// Since after distribution 2 all votes will be given to billy output will be
		// same as test2
		OpenParty p3 = new OpenParty(testFile3);
		Map<Character, Integer> result3 = p3.getPartyVotes();
		// Create testing hashmap and fill it with values
		Map<Character, Integer> expect3 = new HashMap<Character, Integer>();
		expect3.put('R', 2);
		expect3.put('D', 3);
		expect3.put('I', 2);

		assertEquals(expect1, result1);
		assertEquals(expect2, result2);
		assertEquals(expect3, result3);

	}

	/**
	 * Function tests the helperToFind function Want to see that given a map will
	 * give the index for the party with highest amount of votes
	 * @throws IOException if file reading fails
	 */
	@Test
	public void test3() throws IOException {
		// Test depends on the input file.
		OpenParty p1 = new OpenParty(testFile1);
		Map<Character, Integer> map = new HashMap<Character, Integer>();

		int result1 = p1.helperToFind(map);
		int expect1 = 0;

		// Expect 0 as Billy has already been chosen
		OpenParty p2 = new OpenParty(testFile2);
		Map<Character, Integer> map1 = new HashMap<Character, Integer>();
		map1.put('R', 14);
		int result2 = p2.helperToFind(map1);
		int expect2 = 14;

		// Expect 0 since there is no ballots.
		OpenParty p3 = new OpenParty(testFile3);
		Map<Character, Integer> map2 = new HashMap<Character, Integer>();
		map1.put('R', 14);
		int result3 = p2.helperToFind(map2);
		int expect3 = 0;

		assertEquals(expect1, result1);
		assertEquals(expect2, result2);
		assertEquals(expect3, result3);

	}

	/**
	 * Tests returnIndex function. Used as a helper function to find the index of a
	 * 1 "vote" within a ballot so that it can be associated with a given candidate.
	 * @throws IOException if file reading fails
	 */
	@Test
	public void test4() throws IOException {
		OpenParty p2 = new OpenParty(testFile1);

		// Test case where index returned and when no index returned
		// Simple function that works with arrays
		int[] array1 = new int[] { 0, 0, 0, 0, 0 };
		int[] array2 = new int[] { 0, 0, 1, 0, 0 };

		int expect1 = -1;
		int expect2 = 2;

		int result1 = p2.returnIndex(array1);
		int result2 = p2.returnIndex(array2);

		assertEquals(expect1, result1);
		assertEquals(expect2, result2);

	}

	/**
	 * Function tests a function that returns a list with the winners of the
	 * election. Function also test a function called helper. Helper extracts the
	 * candidate with the most votes at each iteration.
	 * @throws IOException if file reading fails
	 */
	@Test
	public void test5() throws IOException {
		// Output depends on file.
		OpenParty p1 = new OpenParty(testFile1);
		OpenParty p2 = new OpenParty(testFile2);
		OpenParty p3 = new OpenParty(testFile3);

		ArrayList<String> result1 = p1.announceWinner();
		ArrayList<String> expect1 = new ArrayList<String>();
		expect1.add("Joe");
		expect1.add("Billy");
		expect1.add("Isaac");

		// No winner since no ballots therefore empty array
		ArrayList<String> result2 = p2.announceWinner();
		ArrayList<String> expect2 = new ArrayList<String>();

		// One winner since one ballot and one seat
		ArrayList<String> result3 = p3.announceWinner();
		ArrayList<String> expect3 = new ArrayList<String>();
		expect3.add("Billy ");

		assertEquals(expect1, result1);
		assertEquals(expect2, result2);
		assertEquals(expect3, result3);

	}

	/**
	 * Function test the opl function. Returns a string that contains all of the
	 * winners seperated by spaces.
	 * @throws IOException if file reading fails
	 */
	@Test
	public void test6() throws IOException {
		// Output depends on file.
		OpenParty p1 = new OpenParty(testFile1);
		OpenParty p2 = new OpenParty(testFile2);
		OpenParty p3 = new OpenParty(testFile3);

		// Expect result string to end in a space
		String result1 = p1.runOPL();
		String expect1 = "Billy Joe Isaac ";

		// Expect no winners since no ballots or seats
		String result2 = p2.runOPL();
		String expect2 = "";

		// Expect one winner since one ballots and seat
		String result3 = p3.runOPL();
		String expect3 = "Billy  ";

		assertEquals(expect1, result1);
		assertEquals(expect2, result2);
		assertEquals(expect3, result3);
	}

	/**
	 * Function tests init log function by calling get log No need to call init log
	 * as it is called in the constructor. Also tests addEventToLog as well as
	 * eventActionToGenerateReportCandidateVotes and
	 * eventActionToGenerateReportPartyVotes.
	 * @throws IOException if file reading fails
	 */
	@Test
	public void test7() throws IOException {
		OpenParty p1 = new OpenParty(testFile1);
		OpenParty p2 = new OpenParty(testFile2);
		OpenParty p3 = new OpenParty(testFile3);

		// Test the log by generating the media report that uses logs
		EventLogger log1 = p1.getLog();
		String result1 = log1.generateReport();
		String expect1 = "This election was held between 5 candidate(s):\n" + "Billy, Sandra, Joe, Luke, Isaac, \n"
				+ "A total of 100 voters voted.\n" + "Joe,98, is assigned to a candidate\n"
				+ "Luke,99, is assigned to a candidate\n" + "Isaac,100, is assigned to a candidate\n"
				+ "Party R,1, First allocation of seats\n" + "Party D,0, First allocation of seats\n"
				+ "Party I,0, First allocation of seats\n" + "Party I,1, 2nd allocation of seats\n"
				+ "Party D,1, 2nd allocation of seats\n";

		// Case where the report has no ballots or seats
		EventLogger log2 = p2.getLog();
		String result2 = log2.generateReport();
		String expect2 = "This election was held between 5 candidate(s):\n" + "Billy, Sandra, Joe, Luke, Isaac, "
				+ "\nA total of 0 voters voted.\n";

		// Case where just one voter votes for Billy
		EventLogger log3 = p3.getLog();
		String result3 = log3.generateReport();
		String expect3 = "This election was held between 5 candidate(s):\n" + "Billy , Sandra, Joe, Luke, Isaac, \n"
				+ "A total of 7 voters voted.\n" + "Luke,6, is assigned to a candidate\n"
				+ "Isaac,7, is assigned to a candidate\n" + "Party R,0, First allocation of seats\n"
				+ "Party D,0, First allocation of seats\n" + "Party I,0, First allocation of seats\n"
				+ "Party D,1, 2nd allocation of seats\n";

		assertEquals(expect1, result1);
		assertEquals(expect2, result2);
		assertEquals(expect3, result3);
	}

}

