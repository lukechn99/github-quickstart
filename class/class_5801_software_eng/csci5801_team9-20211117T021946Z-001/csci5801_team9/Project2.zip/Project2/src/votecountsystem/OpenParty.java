package votecountsystem;

import java.io.*;
import java.nio.file.Files;
import java.util.*;

/**
 *
 * @author Abdikarim Fareh, Rohan
 * @version v1.0
 *
 *      
 *
 */

/**
 * This class reads a csv file that has been identified as "OPL" input
 *          file. it parses through the csv and retrieves all the information
 *          like candidates, parties, number of seats and ballots. The program
 *          goes through and creates Candidate [] Object for candidate names It
 *          also associate their parties as well.
 *
 *          The program reads all Ballots and assign each Ballot to a candidates
 *          once. We also counting their vote as we go through ballot one at a
 *          time
 *
 *          After we finish assigning Ballots, we Identify how many seats should
 *          each party recieve. We do this by using "Largest Remainder Formula"
 *          Once we identify seats for each party, we now identify candidates
 *          with the highest number of votes given a party and number of seats.
 *
 *          Finally the winner is being announced. Have in mind, we log every
 *          single touch we are performing.
 *
 */
public class OpenParty {
	// Event logger is the one that keep tracks of all
	// events taking place
	private EventLogger log;

	// candidate and party arrays
	private Candidate[] candidate_names;
	private char[] parties;

	// get the following lines from the file input
	private int numberOfCandidates;
	private int numberOfBallots;
	private int numberOfSeats;
	private int numberOfParties;

	// this is a representation of a ballot Array for each line
	// that will be assigned to a candidate
	// it's used inside the createBallotArray signature
	int[] arrayBallotVotesPerLine;

	// ballotID -> counter
	int count = 1;

	// this is to track how many votes do each candidate has
	// since we only need to touch the Ballot once, we need to keep track of it
	Map<String, Integer> votecounter = new HashMap<>();

	// this will help us to identify total number of votes per party
	private Map<Character, Integer> partyVotes = new HashMap<>();

	// keep track of how many seats will each party get
	Map<Character, Integer> seats = new HashMap<>();

	// this one keep tracks of total votes cast
	// we can also use number of Ballots,
	int totalVoteCast = 0;

	/**
	 *
	 * @param fileName is the csv
	 * @throws IOException if file not found
	 *
	 *                     Constructor receives file name that is being identified
	 *                     as a OPL csv file it reads line by line
	 */

	public OpenParty(File fileName) throws IOException {
		// initializing my log method
		initLog();

		// save the entire text as a List
		// will this going to fail to read 100, 000
		List<String> ls = Files.readAllLines(fileName.toPath());

		// get token of candidate line
		String lsOfCandidate = ls.get(2);

		numberOfCandidates = Integer.parseInt(ls.get(1));
		numberOfSeats = Integer.parseInt(ls.get(3));
		numberOfBallots = Integer.parseInt(ls.get(4));
		numberOfParties = Integer.parseInt(ls.get(3));

		// read the candidate names' line and split them by
		// each square box
		String[] ar = lsOfCandidate.trim().split("],");

		// initialize array length
		String[] candidateName = new String[numberOfCandidates];
		String[] partyChoice = new String[numberOfCandidates];

		// initializing my array char && Candidate object to the length of
		// how many candidate we have
		candidate_names = new Candidate[numberOfCandidates];
		parties = new char[numberOfCandidates];

		for (int i = 0; i < ar.length; i++) {

			String[] arCopy = ar[i].trim().split(",");
			candidateName[i] = arCopy[0].replace("[", "");
			partyChoice[i] = arCopy[1].replace("]", "");

			parties[i] = partyChoice[i].charAt(0);
			candidate_names[i] = new Candidate(candidateName[i], parties[i]);

			// I will use this to keep track of candidate's votes
			votecounter.put(candidateName[i], 0);
			partyVotes.put(parties[i], 0);

			// log that a candidate was found and created
			log.addEvent(candidateName[i], -1, "Creation of new Candidate");

		}

		initLog();

		for (int i = 0; i < candidate_names.length; i++) {
			System.out.println("Index " + i + " Candidate Name :" + candidate_names[i].getName() + " party : "
					+ candidate_names[i].getParty());
		}

		// System.out.println();

		// given a string of "01000"
		// get ballot array per line as an new int [] {0,1,0,0, 0}
		System.out.println("list: " + ls);
		createBallotArrayPerLine(ls);

		// party numbers
		for (String s : votecounter.keySet()) {
			System.out.println("Name " + s + " Has " + votecounter.get(s));
		}

		System.out.println();

		// print statement for candidate votes
		for (char s : partyVotes.keySet()) {
			System.out.println("Party " + s + " Has total votes of " + partyVotes.get(s));
		}

		System.out.println();

		System.out.println("Total Vote Casted : " + totalVoteCast);

		System.out.println();

		// just using for debugging purposes
		// below signature finds out number of seats each party should get
		identifyNumberOfSeats();
		for (char c : seats.keySet()) {
			System.out.println("Party " + c + " has " + seats.get(c) + " seats");
		}

		eventActionToGenerateReportCandidateVotes();
		eventActionToGenerateReportPartyVotes();

	}

	/**
	 *
	 * @param ls takes List of String from the input file to parse through the
	 *           ballots
	 * @return returns the array of ints that represent ballots
	 */
	public int[] createBallotArrayPerLine(List<String> ls) {
		// the ballot will always start at line number k
		// where k is 5 all the way to end of the list
		if (numberOfBallots > 0) {
			for (int k = 5; k < ls.size(); k++) {
				// receive each line and place 0 if there is nothing
				String input = ls.get(k).trim().replaceAll(",", "0");

				// Initializing Ballot size per line
				arrayBallotVotesPerLine = new int[input.length()];

				for (int p = 0; p < input.length(); p++) {
					arrayBallotVotesPerLine[p] = Character.getNumericValue(input.charAt(p));
				}

				// now is the time we need to find the candidate it belongs to
				// and assigned to them
				assigningBallotTocandidate(arrayBallotVotesPerLine);
			}
		}
		return arrayBallotVotesPerLine;
	}

	/**
	 *
	 * This is a helper function that will receive a Ballot ( continuously ) and
	 * assigns to a candidate if that ballot has a at least a vote As we assign
	 * ballots to candidate, we also counting their votes
	 * 
	 * @param arrayBallotVotesPerLine2 assigns votes to candidate
	 * @return the candidate name
	 */
	public String assigningBallotTocandidate(int[] arrayBallotVotesPerLine2) {
		Ballot ballotObj;

		// get the index of 1, and associate with it's owner ( a candidate )
		// {1,0,0,0,0} it will return index 0
		int keeper = returnIndex(arrayBallotVotesPerLine2);

		if (keeper >= 0) {
			// create a Ballot object Ballot ( count, arrayBalotVotesperline2,
			// candidate_name[keep].getparty)
			ballotObj = new Ballot(count, arrayBallotVotesPerLine2);
			candidate_names[keeper].addVote(ballotObj);

			// ballot is assigned to a candidate
			log.addEvent(candidate_names[keeper].getName(), ballotObj.getID(), " is assigned to a candidate");

			// keep track of candidates vote
			votecounter.put(candidate_names[keeper].getName(), votecounter.get(candidate_names[keeper].getName()) + 1);

			// keep track of parties' total vote
			partyVotes.put(candidate_names[keeper].getParty(), partyVotes.get(candidate_names[keeper].getParty()) + 1);

			// I need to log an event

			// number of ballots created ;
			count++;

			// Increment total vote cast
			totalVoteCast++;
			return candidate_names[keeper].getName();

		} else {
			// when the Ballot has nothing (0,0,0,0,0 based on the candidate)
			log.addEvent("No candidate", count, " Discarded ");
			return "No candidate";
		}

	}

	/**
	 * This method identifies number of seats that each party should receive This is
	 * where we use the Formula called "Largest remainder Formula" This method also
	 * takes care of 2nd allocation
	 */
	public void identifyNumberOfSeats() {
		int quota = 0;
		if (numberOfSeats > 0) {
			quota = totalVoteCast / numberOfSeats;
		} else {
			quota = 1;
		}

		ArrayList<Integer> lst = new ArrayList<>();
		ArrayList<Character> tieP = new ArrayList<>();

		System.out.println("Quota is " + quota);

		// keep updating number of seats
		// for now it's zero for all party
		int temp = 0;

		// we will use to keep track of the max-value for 2nd allocation seats
		for (char c : partyVotes.keySet()) {

			int remainder = partyVotes.get(c) % quota;
			temp = Math.floorDiv(partyVotes.get(c), quota);
			if (numberOfSeats != 0) {
				// update number of seats they deserve
				seats.put(c, temp);
				log.addEvent("Party " + Character.toString(c), seats.get(c), " First allocation of seats");
				partyVotes.put(c, remainder);
				numberOfSeats -= temp;
			}
		}

		// keep the record of reminder for 2nd round allocation
		for (char c : partyVotes.keySet()) {
			lst.add(partyVotes.get(c));
		}
		// sort the list in Desc order
		Collections.sort(lst, Collections.reverseOrder());

		// printing out what the list of lst is
		// for ( int i =0; i< lst.size(); i++){
		// System.out.println("Printing lst " + lst.get(i));
		// }

		// for 2nd Allocation
		// will there be a possible tie, I have to verify
		while (numberOfSeats > 0) {
			// when there is a tie
			for (int i = 1; i < lst.size(); i++) {
				int n = lst.get(0);
				// there is a tie
				if (n == lst.get(i)) {
					for (char cc : partyVotes.keySet()) {
						if (n == partyVotes.get(cc)) {
							tieP.add(cc);
						}
					}
					// tie list character
//					for (int j = 0; j < tieP.size(); j++) {
//						System.out.println("Tie Char are : " + tieP.get(j));
//					}
					char lucky = tieBreaker2(tieP);
					// given has # of candidates for a given party
					int given = numberOfCandidatesGivenParty(lucky);
					if (given > seats.get(lucky)) {
						seats.put(lucky, seats.get(lucky) + 1);
						log.addEvent("Party " + Character.toString(lucky), seats.get(lucky),
								" 2nd allocation of seats");
						lst.remove(lst.indexOf(partyVotes.get(lucky)));
					}

				} else {
					// ther eis NO ties
					for (char cc : partyVotes.keySet()) {
						if (n == partyVotes.get(cc)) {
							// given has # of candidates for a given party
							int given = numberOfCandidatesGivenParty(cc);
							// if # of candidate is more than seats, then keep adding
							// seats
							if (given > seats.get(cc)) {
								// update their seat number
								seats.put(cc, seats.get(cc) + 1);
								log.addEvent("Party " + Character.toString(cc), seats.get(cc),
										" 2nd allocation of seats");

							}
							// else , we will remove that guy and go down the list
							// System.out.println("updateing inside else " + cc);
							lst.remove(0);
							// System.out.println("Removing " + lst.remove(0));
						}
					}
				}
			}
			numberOfSeats--;
		}
	}

	/**
	 * @param p is the party name
	 * @return ArrayList Integer in desc order
	 */
	// given a party, give me their votes in a Desc order
	public ArrayList<Integer> helperVotes(char p) {
		ArrayList<Integer> ll = new ArrayList<>();
		for (int c = 0; c < candidate_names.length; c++) {
			if (candidate_names[c].getParty() == p) {
				ll.add(candidate_names[c].getCurCount());
			}
		}
		Collections.sort(ll, Collections.reverseOrder());
//
//		for (int l = 0; l < ll.size(); l++) {
//			System.out.println(" Given party " + p + ", the list are : " + ll.get(l) + " ");
//		}

		return ll;
	}

	/**
	 * @return ArrayList String of winners
	 */
	// new announce winner
	public ArrayList<String> announceWinner() {
		int sits = 0;

		ArrayList<Integer> ll = new ArrayList<>();

		ArrayList<String> winner = new ArrayList<>();

		ArrayList<String> tie = new ArrayList<>();

		for (char c : seats.keySet()) {
			sits = seats.get(c);
			// get the list of all candidates' votes belong to this party
			ll = helperVotes(c);

			while (sits > 0) {
				for (int l = 0; l < ll.size(); l++) {
					int n = ll.get(0);

					// There is a Tie
					if (n == ll.get(l)) {

						for (int cc = 0; cc < candidate_names.length; cc++) {
							if (c == candidate_names[cc].getParty() && n == candidate_names[cc].getCurCount()) {
								tie.add(candidate_names[cc].getName());
								ll.remove(0);
							}
						}

//						for (int tt = 0; tt < tie.size(); tt++) {
//							System.out.println("Tie candidates are : " + tie.get(tt));
//						}
						System.out.println();

						tie = tieBreaker(tie, sits);

//						for (int tt = 0; tt < tie.size(); tt++) {
//							System.out.println("Tie candidates winners are : " + tie.get(tt));
//						}

						for (int t = 0; t < tie.size(); t++) {
							winner.add(tie.get(t));
						}

						tie.clear();

					} else {

						for (int cc = 0; cc < candidate_names.length; cc++) {
							if (c == candidate_names[cc].getParty() && n == candidate_names[cc].getCurCount()) {
								winner.add(candidate_names[cc].getName());
							}
						}

						ll.remove(0);
					}

				}
				sits--;
			}

		}

		for (int wi = 0; wi < winner.size(); wi++) {
			System.out.println(" winners are : " + winner.get(wi) + " ");
		}
		return winner;
	}

	/**
	 * Announce winners by looping through List of winners
	 * 
	 * @return the winners
	 */
	public String runOPL() {

		ArrayList<String> win = new ArrayList<>();

		String elected = "";

		win = announceWinner();

		for (int i = 0; i < candidate_names.length; i++) {
			for (int j = 0; j < win.size(); j++) {
				if (candidate_names[i].getName().equals(win.get(j))) {
					elected = elected + candidate_names[i].getName() + " ";
					log.addEvent(candidate_names[i].getName(), candidate_names[i].getCurCount(), " Winner");
				}
			}
		}
		return elected;
	}

	/**
	 *
	 * @param bArray takes in Array of Ballot
	 * @return helper function to return where there is "1" in a ballot so that we
	 *         can assigned to the intended candidate
	 */
	public int returnIndex(int[] bArray) {
		for (int i = 0; i < bArray.length; i++) {
			if (bArray[i] == 1) {
				return i;
			}
		}
		return -1;
	}

	/**
	 * This is my initLog, it initializes my log as soon as we read candidate line
	 */
	public void initLog() {
		String[] names = new String[numberOfCandidates];
		for (int i = 0; i < numberOfCandidates; i++) {
			names[i] = candidate_names[i].getName();
		}
		log = new EventLogger("OPL", numberOfCandidates, names, parties, numberOfBallots, numberOfSeats);
	}

	/**
	 *
	 * @return all logs that were saved
	 */
	public EventLogger getLog() {
		return log;
	}

	/**
	 * @param c is the candidate
	 * @param b is the ballot
	 * @param a is any action that is taking place an event will be activated once
	 *          we found an activity is taking taking place
	 */
	public void addEventToLog(String c, int b, String a) {
		log.addEvent(c, b, a);
	}

	/**
	 * report number of votes per candidate to the eventlogger
	 */
	public void eventActionToGenerateReportCandidateVotes() {
		int v[] = new int[numberOfCandidates];
		for (int i = 0; i < candidate_names.length; i++) {
			v[i] = candidate_names[i].getCurCount();
		}
		log.reportCandidateVotes(v);
	}

	/**
	 * report number of votes for the entire party to eventlogger
	 */
	public void eventActionToGenerateReportPartyVotes() {
		int n = 0;
		int pv[] = new int[numberOfCandidates];
		for (int j = 0; j < parties.length; j++) {
			for (int i = 0; i < candidate_names.length; i++) {
				if (Character.compare(parties[j], candidate_names[i].getParty()) == 0) {
					n += candidate_names[i].getCurCount();
				}
			}
			pv[j] = n;
			n = 0;
		}
		log.reportPartyVotes(pv);
	}

	/**
	 * @return map with amount of votes for each party
	 */
	public Map<Character, Integer> getPartyVotes() {
		return partyVotes;
	}

	/**
	 * @param tied_candidates candidates where tie happened
	 * @param numbSeats number of seats for a given party
	 * @return ArrayList String of candidate names
	 */
	// Tie Breaker Between Candidates
	public ArrayList<String> tieBreaker(ArrayList<String> tied_candidates, int numbSeats) {
		Random r = new Random();
		int coin;
		while (tied_candidates.size() > numbSeats) {
			// either remove the first candidate, or the second based on coin flip
			int heads = 0;
			int tails = 0;
			for (int i = 0; i < 1001; i++) {
				coin = r.ints(0, 2).findFirst().getAsInt();
				if (coin == 0) {
					heads++;
				} else {
					tails++;
				}
			}
			if (heads > tails) {
				tied_candidates.remove(0);
			} else {
				tied_candidates.remove(1);
			}
		}
		// eliminate the first candidate in the list which should also be the
		// only candidate left
		return tied_candidates;
	}

	/**
	 * @param tied_candidates where tie needs to be broken between parties
	 * @return char name of party that won the tie
	 */
	// Tie Breaker Between Parties
	public char tieBreaker2(ArrayList<Character> tied_candidates) {
		Random r = new Random();
		int coin;
		while (tied_candidates.size() > 1) {
			// either remove the first candidate, or the second based on coin flip
			int heads = 0;
			int tails = 0;
			for (int i = 0; i < 1001; i++) {
				coin = r.ints(0, 2).findFirst().getAsInt();
				if (coin == 0) {
					heads++;
				} else {
					tails++;
				}
			}
			if (heads > tails) {
				tied_candidates.remove(0);
			} else {
				tied_candidates.remove(1);
			}
		}
		// eliminate the first candidate in the list which should also be the
		// only candidate left
		return tied_candidates.get(0);
	}

	/**
	 * @param p given party name
	 * @return int how many candidate belong to the party
	 */
	// it return total number of candidates
	// given a party name so that we can identify
	// if seats can be allocated or not
	public int numberOfCandidatesGivenParty(char p) {
		int res = 0;
		for (int c = 0; c < candidate_names.length; c++) {
			if (p == candidate_names[c].getParty()) {
				res++;
			}
		}
		return res;
	}

	/**
	 * @param s candidate name
	 * @return char, returns the party given candidate belong to
	 */
	public char givenNameGetParty(String s) {
		char charP = '\0';

		for (int c = 0; c < candidate_names.length; c++) {
			if (candidate_names[c].getName().equalsIgnoreCase(s)) {
				charP = candidate_names[c].getParty();
			}
		}
		return charP;
	}

	/**
	 * @param p party name
	 * @return ArrayList String returns list of candidates that belong to the same
	 *         party
	 */
	public ArrayList<String> listOFCandidates(char p) {
		ArrayList<String> st = new ArrayList<>();

		for (int i = 0; i < candidate_names.length; i++) {
			if (p == candidate_names[i].getParty()) {
				st.add(candidate_names[i].getName());
			}
		}

		return st;
	}

	/**
	 * @param p party name
	 * @return int, returns number of seats that each party has
	 */
	public int seatsPerParty(char p) {
		int sit = 0;
		for (char c : partyVotes.keySet()) {
			if (p == c) {
				sit = seats.get(c);
			}
		}
		return sit;
	}

	/**
	 *
	 * @param pv this takes Map parameter that has party names and their total vote as
	 *             a party
	 *
	 * @return return the index of the party with the highest reminder for 2nd
	 *         allocation in order to get fair distribution of seats
	 */
	public int helperToFind(Map<Character, Integer> pv) {
		int n = 0;
		for (char c : pv.keySet()) {
			if (pv.get(c) > n)
				n = pv.get(c);
		}
		return n;
	}

}
