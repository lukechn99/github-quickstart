package votecountsystem;

import java.util.*;

/**
 * A ballot holds its ID information and its choices of candidates in an array
 * of ints
 */
public class Ballot {
    private int ID;
    private int[] choices;
    private int round;

    /**
     * 
     * @param id is the ID assigned
     * @param c is the list of vote preferences
     */
    public Ballot(int id, int[] c) {
        ID = id;
        choices = Arrays.copyOf(c, c.length);
        round = 1;
        // System.out.println("Ballot " + Integer.toString(id) + " was created with
        // choices " + Arrays.toString(choices));
    }

    /**
     * copy constructor of a ballot allows for redistribution
     * 
     * @param b is the ballot to be constructed with
     */
    public Ballot(Ballot b) {
        ID = b.getID();
        choices = Arrays.copyOf(b.getChoices(), b.getChoices().length);
        round = b.getRound();
    }

    /**
     * 
     * @return int ID
     */
    public int getID() {
        return ID;
    }

    /**
     * 
     * @return int[] choices
     */
    public int[] getChoices() {
        return choices;
    }

    /**
     * Will return the nth choice. For example, a ballot that has choices = {1, 0,
     * 0, 2, 0, 3}, getNth(2) will return 3 because 3 is the index/candidate that
     * corresponds to the ballot's second choice
     * 
     * @param round is the round requested
     * @return returns the nth choice of that candidate or -1 if not found
     */
    public int getNthChoice(int round) {
        for (int i = 0; i < choices.length; i++) {
            if (choices[i] == round) {
                return i;
            }
        }
        return -1;
    }

    /**
     * the round we look at for a ballot is independent of other ballots so each
     * ballot needs to keep track of its own round
     * 
     * @return int current round
     */
    public int getRound() {
        return round;
    }

    /**
     * adds 1 to the current round
     */
    public void incrementRound() {
        round++;
    }
}
