from random import randint
import time
import csv

names = ["Billy", "Sandra", "Joe", "Luke", "Isaac",
         "Shana", "Abdikarim", "Rohan", "Ike", "Mandy"]
parties = ["D", "I", "R", "R", "I", "L", "D", "D", "R", "R"]

# Generates an OPL test file as .txt


def txtopl(c, b, copy, s):
    file = open("opl" + str(copy) + "_" +
                str(time.time()) + ".txt", "w")
    file.write("OPL\n")
    file.write(str(c) + "\n")
    c_names = ""
    for i in range(c - 1):
        c_names += "[" + names[i] + "," + parties[i] + "], "
    c_names += "[" + names[c - 1] + "," + parties[i] + "]"
    file.write(str(c_names) + "\n")
    file.write(str(s) + "\n")
    file.write(str(b) + "\n")
    for i in range(b):
        ballot = ""
        cast = randint(0, c - 1)
        for i in range(c - 1):
            if i == cast:
                ballot += "1"
            ballot += ","
        if (c - 1) == cast:
            ballot += "1"
        file.write(ballot + "\n")
    file.close()

# Generates an OPL test file as .csv


def opl(c, b, copy, s):
    with open("opl" + str(copy) + "_" + str(time.time()) + ".csv", 'w') as file:
        writer = csv.writer(file)
        writer.writerow(["OPL"])
        writer.writerow([str(c)])
        c_names = []
        for i in range(c):
            candidate = '[' + names[i] + ',' + parties[i] + ']'
            c_names.append(candidate)
        writer.writerow(c_names)
        writer.writerow([str(s)])
        writer.writerow([str(b)])
        for i in range(b):
            ballot = []
            cast = randint(0, c - 1)
            for i in range(c - 1):
                if i == cast:
                    ballot.append("1")
                ballot.append("")
            if (c - 1) == cast:
                ballot.append("1")
            writer.writerow(ballot)

# Generates an IR test file as a .txt


def txtir(c, b, copy):
    file = open("ir" + str(copy) + "_" + str(c) + "_" +
                str(b) + "_" + str(time.time()) + ".txt", "w")
    file.write("IR\n")
    file.write(str(c) + "\n")
    c_names = ""
    for i in range(c - 1):
        c_names += names[i] + " (" + parties[i] + "), "
    c_names += names[c - 1] + " (" + parties[i] + ")"
    file.write(str(c_names) + "\n")
    file.write(str(b) + "\n")
    for i in range(b):
        ballot = ""
        cast = randint(1, c)    # number of people voted for
        order = {}              # key will be their rank, value will be who
        for candidate in range(cast):
            pos = randint(0, c)
            while pos in order:
                pos = randint(0, c)
            order[pos] = candidate
        for i in range(c - 1):
            if i in order:
                ballot += str(order[i] + 1)
            ballot += ","
        if (c - 1) in order:
            ballot += str(order[c - 1] + 1)
        file.write(ballot + "\n")
    file.close()

# Generates an IR test file as a .csv


def ir(c, b, copy):
    with open("ir" + str(copy) + "_" + str(time.time()) + ".csv", 'w') as file:
        writer = csv.writer(file)
        writer.writerow(["IR"])
        writer.writerow([str(c)])
        c_names = []
        for i in range(c):
            candidate = names[i] + " (" + parties[i] + ")"
            c_names.append(candidate)
        writer.writerow(c_names)
        writer.writerow([str(b)])
        for i in range(b):
            ballot = []
            cast = randint(1, c)    # number of people voted for
            order = {}              # key will be their rank, value will be who
            for candidate in range(cast):
                pos = randint(0, c)
                while pos in order:
                    pos = randint(0, c)
                order[pos] = candidate
            for i in range(c):
                if i in order:
                    ballot.append(str(order[i] + 1))
                else:
                    ballot.append("")
            writer.writerow(ballot)


def generate(type, candidates, ballots, seats, copies):
    '''
    type : "OPL" or "IR"
    candidates : int
    ballots : int
    copies : int

    Produce "copies" number of unique vote CSVs with "candidates"
    number of candidates and "ballots" number of ballots following
    the CSV format provided by Shana Watters
    '''
    if candidates > len(names) or candidates < 1:
        print("give more candidate names to continue")
    if type == "OPL":
        for i in range(copies):
            opl(candidates, ballots, i, seats)
    elif type == "IR":
        for i in range(copies):
            ir(candidates, ballots, i)


print("for type, you need to use 'OPL' or 'IR' (with the quotations),")
print("and input the number of candidates you would like to run")
print("with (max 10), the number of ballots you want to simulate (no max),")
print("the number of parties (for OPL) and the number of unique copies you ")
print("want to generate. These will be created in your running directory")
type = input('Type = ')
candidates = int(input('Candidates = '))
ballots = int(input('Ballots = '))
seats = 0
if type == "OPL":
    seats = int(input('Seats = '))
copies = int(input('Copies = '))
generate(type, candidates, ballots, seats, copies)
print("done")
