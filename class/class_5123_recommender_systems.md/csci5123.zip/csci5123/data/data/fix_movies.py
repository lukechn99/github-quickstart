import csv

movies = open("filepath")

genres = ["Unkown","Action","Adventure","Animation","Children","Comedy","Crime","Documentary","Drama","Fantasy","Film Noir","Horror","Musical","Mystery","Romance","Sci-Fi","Thriller","War","Western"]

for row in movies:
    cur_str = ""
    movie_genres = row[2].split("|")

    #convert genres to 0s and 1s
    for genre in genres:
        if genre in movie_genres:
            cur_str += (genre + ",")
    
    #reassign row
    row[2] = cur_str
    movies[cur_idx] = row
    