# Replication Assignment Notes

*// Jacob Arkadie 12/02/2021*
## Preference Estimation Subproblem (PES)
---
# $$\Sigma^{K}_{k=1} \Sigma^{N}_{i=1} \ r_iy_i^k\lambda_k$$
---
#### $$Goal:\ Find\ the\ min\ \lambda\ value$$

---
Key:
- $K$ = # of Permutations = $N!$
- $N$ = |{All Unique Items}|
- **$r_i$** - rating of item i
- **$y_i^k$** -  Binary decision variable (1 or 0)
- $\lambda_k$ - Continuous Decision Variable $\geq$ 0 $\forall k\{1..K\}$
---
##### Definitions
___
**Column Generation** - An Algorithm used to efficiently solve large linear problem which work to only find the variables with negative reduced cost [More info](https://en.wikipedia.org/wiki/Column_generation)

---

##### Interpretation of The Steps
---
1. Without Constraint to Set $P = \{p_1,p_2..p_k\}$ choose a random permutation --> Run PES and obtain optimal solution *x*
2. We compare *x* to the value of solving the **Price Problem** and set the value accordingly.
	1. Choose a random permutation $\sigma$ and a neighbor $\sigma^\prime$ *(switch any two items)*
	2. If $\sigma^\prime$ provides a better reduced cost we repeat step one w/ $\sigma^\prime$  Else: Terminate w/ $\sigma$ as the local minimum 
3. If the optimal solution *x* is negative we use a set of associated permutations and repeat step 1 with this constrained set. Otherwise we stop iterating.
___

#### Pseudo Code (In progress)
```
def PrefEstimation(M -> Item Permutation):
	
```

## 