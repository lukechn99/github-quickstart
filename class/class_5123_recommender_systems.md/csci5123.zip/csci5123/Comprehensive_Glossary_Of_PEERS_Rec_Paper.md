### Variable Key
---
+ $m$ - # of items to recommend at a time
+ $N$ -  Catalog of relevant items to chose from
+ $x_i$ -  Binary variable; 1 = Item is presented to user, 0 = Otherwise
+ $r_i$ - Reward of item i (clicks,profit,revenue,etc)
+ $\sigma$ - permutation of items in order of customer preference
+ $M$ - set of provided items (the recommendation list)
+ $i_0$ -  "no-purchase" option
+ $\lambda$ -  vector denoting probability of each permutation
+ $y_i^k$ - Binary Variable; Denotes if item i is highest ranked in a permutation $\sigma$
+ $K$ -  Total Number of permutations
+ $S$ - 
+ $|x| = |\bar Y| = |\lambda|$
---
### The Breakdown
+ Preference Estimation Subproblem  -> Determine $\lambda$
+ Recommendation Optimization Subproblem -> Determine $x$ and $Y$
+ Decomposition Algorithm -> Use Estimated Distribution $\hat \lambda$ and $y_i^k$ to calculate a constraint  and feed it into the recommendation optimization problem. -> Leads to local optimal recommendation, *repeat all these steps until convergence*